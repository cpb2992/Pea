import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {
  ActivityIndicator, Alert, Image, KeyboardAvoidingView, Linking, Modal,
  Platform, Pressable, ScrollView, Share, StatusBar, StyleSheet, Switch,
  Text, TextInput, View, AppState as NativeAppState,
} from 'react-native';
import {SafeAreaProvider, SafeAreaView} from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import {Ionicons} from '@expo/vector-icons';
import {addDays, dayKey, initialState, meals, officialResources, workTemplates, treatCategories, treatStatusLabel, nextTreatStatus, safePersonalLink} from './src/data';
import type {AppState, Assignee, FamilyEvent, Meal, Section, Task, Treat, TreatCategory} from './src/data';
import {clearPrivateNotification, enablePrivateDailyNotification} from './src/notifications';
import {colors as C, shadow} from './src/theme';
import {getPicks, getRestrictions, getFederalNotices, restrictionSnapshot, URLS} from './src/live';
import type {FeedCategory, LivePick, CountryCategory, Restrictions, RuleNotice} from './src/live';
import {ACTIVITIES,PRIZES,WEEKLY_POINTS_CAP,PEA_TOKEN_VALUE,emptyBank,canClaim,claimActivity,redeemPrize,pointsThisWeek,peasVisible,projectedWeeks,projectedTimeframe,TYPICAL_WEEKLY_POINTS} from './src/rewards';
import type {RewardActivityId,RewardPrizeId} from './src/rewards';
import {dailyWisdom} from './src/wisdom';

const STORAGE_KEY='pea.planner.v1'; // Keep key to migrate original Pea plans in place.
const PRIVATE_KEY='pea.personal_reminder.v1';
// Public entertainment/regulatory requests never include personal or university information.

const ICON=require('./assets/icon.png');
const POD_MARK=require('./assets/pea-pod-mark.png');
const PEA_WORDMARK=require('./assets/pea-wordmark.png');
type Tab='today'|'family'|'meals'|'work'|'pod';
type IconName=React.ComponentProps<typeof Ionicons>['name'];
const weekdays=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const unique=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
const fmtDate=(d:Date)=>d.toLocaleDateString('en-US',{weekday:'long',month:'short',day:'numeric'});
const two=(n:number)=>String(n).padStart(2,'0');
const friendlyTime=(h:number,m:number)=>`${h%12||12}:${two(m)} ${h>=12?'PM':'AM'}`;
const defaultStarter=[
  ['Pack school lunches','home','Partner'],
  ['Do the dishes','home','Partner'],
  ['Choose dinner','home','Pankhuri'],
  ['Set out backpacks & clothes','home','Partner'],
] as const;
function withNewDay(old:AppState,date:string):AppState {
  if((old.preparedDates??[]).includes(date)) return old;
  // Routines are newly created only when a new calendar date begins; no data from BU.
  return {...old,preparedDates:[...(old.preparedDates??[]),date],tasks:[...old.tasks,...defaultStarter.map(([title,section,assignee],i)=>({id:`routine-${date}-${i}`,title,date,section,assignee,done:false}))]};
}
function SmallIcon({name,size=20,color=C.green}: {name:IconName;size?:number;color?:string}){return <Ionicons name={name} size={size} color={color}/>;}
function Card({children,style,pressed,onPress}:{children:React.ReactNode;style?:any;pressed?:boolean;onPress?:()=>void}){
  return onPress ? <Pressable onPress={onPress} style={[styles.card,style,pressed&&{opacity:.75}]}>{children}</Pressable>
    :<View style={[styles.card,style]}>{children}</View>;
}
function TinyLabel({children}:{children:React.ReactNode}){return <Text style={styles.tinyLabel}>{children}</Text>;}
function Action({title,onPress,icon,variant='green',style}:{title:string;onPress:()=>void;icon?:IconName;variant?:'green'|'pink'|'outline';style?:any}){
  const outline=variant==='outline';const bg=outline?C.white:variant==='pink'?C.pinkSoft:C.green;
  const fg=variant==='green'?C.white:C.text;
  return <Pressable onPress={onPress} style={({pressed})=>[styles.action,{backgroundColor:bg,borderWidth:outline?1:0,borderColor:C.line,opacity:pressed?.73:1},style]}>
    {icon&&<SmallIcon name={icon} size={16} color={fg}/>}<Text style={[styles.actionText,{color:fg}]}>{title}</Text>
  </Pressable>;
}
function Heading({title,subtitle,right}:{title:string;subtitle?:string;right?:React.ReactNode}){
  return <View style={styles.headingRow}><View style={{flex:1}}><Text style={styles.heading}>{title}</Text>{subtitle?<Text style={styles.subheading}>{subtitle}</Text>:null}</View>{right}</View>;
}
function TaskRow({task,onToggle,onLongPress,compact=false}:{task:Task;onToggle:()=>void;onLongPress?:()=>void;compact?:boolean}){
  return <Pressable onPress={onToggle} onLongPress={onLongPress} style={[styles.taskRow,compact&&{paddingVertical:11}]}>
    <SmallIcon name={task.done?'checkmark-circle':'ellipse-outline'} size={23} color={task.done?C.green:C.pink}/>
    <View style={{flex:1}}><Text style={[styles.taskTitle,task.done&&styles.strike]}>{task.title}</Text>{!compact?<Text style={styles.meta}>{task.assignee==='Partner'?'Partner’s list':'Pankhuri’s list'} · {task.section==='work'?'Work':'Home'}</Text>:null}</View>
  </Pressable>;
}
const recipeSteps:Record<string,string[]>={
  l1:['Spread cheese or a family-favorite filling over a tortilla.','Roll tightly, slice into little rounds and add washed berries.','Pack crunchy carrots separately with an ice pack.'],
  l2:['Cook pasta, rinse with cool water and drain well.','Add sliced cucumber and a little dressing if liked.','Pack with strawberries in a chilled lunchbox.'],
  l3:['Portion crackers, cheese cubes and apple slices into separate sections.','Add a sliced cucumber for crunch.','Keep chilled until lunchtime.'],
  l4:['Cut pita into dipping triangles.','Pack hummus in a leakproof container and add washed fruit and carrots.','Use an ice pack for food safety.'],
  l5:['Reheat cooked rice and protein thoroughly, then cool quickly.','Add vegetables and a favorite sauce in a separate container.','Refrigerate until packing; keep lunch safely chilled.'],
  d1:['Boil pasta according to the package.','Warm a little cream and pesto in a pan; stir in tomatoes.','Toss with cooked pasta and serve.'],
  d2:['Heat oven to 425°F / 220°C and cut potatoes into small pieces.','Toss chicken and vegetables with olive oil and seasoning on a sheet pan.','Roast until chicken reaches a safe internal temperature of 165°F / 74°C.'],
  d3:['Warm beans with seasoning and a splash of water.','Set out tortillas, shredded lettuce, cheese and diced tomatoes.','Let everyone build their own tacos.'],
  d4:['Scramble eggs in a pan and set aside.','Cook mixed vegetables, add leftover chilled rice and stir-fry until steaming hot.','Stir eggs back in and season with soy sauce.'],
  d5:['Cook chicken to 165°F / 74°C or warm paneer in a skillet.','Simmer with prepared butter chicken sauce.','Serve with cooked rice and a side of peas.'],
  d6:['Cook salmon to a safe internal temperature of 145°F / 63°C.','Prepare rice and slice cucumber.','Serve in bowls with a quick yogurt sauce.'],
};
const pill=(selected:boolean)=>({backgroundColor:selected?C.green:C.white,borderColor:selected?C.green:C.line});

function Main(){
  const [tab,setTab]=useState<Tab>('today');
  const [state,setState]=useState<AppState>(initialState);
  const [loaded,setLoaded]=useState(false);
  const [dateOffset,setDateOffset]=useState(0);
  const [dayAnchor,setDayAnchor]=useState(dayKey(new Date()));
  const [modal,setModal]=useState<'task'|'grocery'|'reminder'|'template'|'event'|'recipe'|'treat'|null>(null);
  const [eventTime,setEventTime]=useState('08:00');
  const [eventCategory,setEventCategory]=useState<FamilyEvent['category']>('School');
  const [newTitle,setNewTitle]=useState('');
  const [newSection,setNewSection]=useState<Section>('home');
  const [newAssignee,setNewAssignee]=useState<Assignee>('Partner');
  const [selectedTemplate,setSelectedTemplate]=useState(0);
  const [selectedRecipe,setSelectedRecipe]=useState<Meal>(meals[0]);
  const [hourValue,setHourValue]=useState('20');
  const [minuteValue,setMinuteValue]=useState('00');
  const [reminderLabel,setReminderLabel]=useState('Personal check-in');
  const [reminderVisible,setReminderVisible]=useState(false);
  const [notificationBusy,setNotificationBusy]=useState(false);
  const [podView,setPodView]=useState<'main'|'me'|'discover'|'rewards'>('main');
  const [workView,setWorkView]=useState<'main'|'policy'>('main');
  const [pickCategory,setPickCategory]=useState<FeedCategory>('movie');
  const [livePicks,setLivePicks]=useState<LivePick[]>([]);
  const [pickLoading,setPickLoading]=useState(false);
  const [pickError,setPickError]=useState('');
  const [pickChecked,setPickChecked]=useState('');
  const [restrictions,setRestrictions]=useState<Restrictions>(restrictionSnapshot);
  const [restrictionLoading,setRestrictionLoading]=useState(false);
  const [restrictionError,setRestrictionError]=useState('');
  const [notices,setNotices]=useState<RuleNotice[]>([]);
  const [noticesError,setNoticesError]=useState('');
  const [noticesLoading,setNoticesLoading]=useState(false);
  const [countrySearch,setCountrySearch]=useState('');
  const [countryCategory,setCountryCategory]=useState<'all'|CountryCategory>('all');
  const [showCountries,setShowCountries]=useState(false);
  const lastPickTry=useRef('');
  const lastWorkTry=useRef(false);
  const [treatFilter,setTreatFilter]=useState<TreatCategory>('thriller');
  const [newTreatCategory,setNewTreatCategory]=useState<TreatCategory>('thriller');
  const [newTreatTitle,setNewTreatTitle]=useState('');
  const [newTreatNote,setNewTreatNote]=useState('');
  const [newTreatUrl,setNewTreatUrl]=useState('');

  const date=useMemo(()=>addDays(new Date(`${dayAnchor}T12:00:00`),dateOffset),[dayAnchor,dateOffset]);
  const key=dayKey(date);
  const todayKey=dayKey(new Date());
  const isToday=key===todayKey;
  const allTasks=useMemo(()=>state.tasks.filter(t=>t.date===key),[state.tasks,key]);
  const homeTasks=allTasks.filter(t=>t.section==='home');
  const calendarEvents=(state.events??[]).filter(e=>e.date===key).sort((a,b)=>a.time.localeCompare(b.time));
  const workTasks=allTasks.filter(t=>t.section==='work');
  const remaining=allTasks.filter(t=>!t.done);
  const chosen=state.mealChoices[key]??{};
  const lunch=meals.find(m=>m.id===chosen.lunch)??meals[0];
  const dinner=meals.find(m=>m.id===chosen.dinner)??meals.find(m=>m.kind==='dinner')!;
  const hasPrivateDone=state.reminder.doneDates.includes(key);
  const homeCompleted=homeTasks.filter(t=>t.done).length;
  const rewardBank=state.rewardBank??emptyBank();
  const thisWeekPeas=pointsThisWeek(rewardBank,todayKey);

  useEffect(()=>{
    const sub=NativeAppState.addEventListener('change',status=>{if(status==='active')setDayAnchor(dayKey(new Date()));});
    return ()=>sub.remove();
  },[]);
  useEffect(()=>{
    let mounted=true;
    (async()=>{
      try {
        const [stored,privateStored]=await Promise.all([AsyncStorage.getItem(STORAGE_KEY), SecureStore.getItemAsync(PRIVATE_KEY)]);
        const parsed:AppState=stored?JSON.parse(stored):initialState();
        const privateData=privateStored?JSON.parse(privateStored):null;
        if(!mounted)return;
        const defaults=initialState();
        const safe={...defaults,...parsed,treats:Array.isArray(parsed.treats)?parsed.treats:[],events:parsed.events??[],preparedDates:parsed.preparedDates??[dayKey(new Date())],rewardBank:parsed.rewardBank??emptyBank(),wisdomEnabled:parsed.wisdomEnabled??true,reminder:{...defaults.reminder,...(privateData??{})}};
        setState(withNewDay(safe,dayKey(new Date())));
      }catch(e){Alert.alert('Couldn’t load saved plans','Pea will start with a fresh local planner.');}
      finally{if(mounted)setLoaded(true);}
    })();
    return ()=>{mounted=false;};
  },[]);
  useEffect(()=>{
    if(!loaded)return;
    // Keep personal reminders and their completion history separate from the ordinary planner.
    AsyncStorage.setItem(STORAGE_KEY,JSON.stringify({...state,reminder:initialState().reminder})).catch(()=>{});
    SecureStore.setItemAsync(PRIVATE_KEY,JSON.stringify(state.reminder),{keychainAccessible:SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY}).catch(()=>{});
  },[state,loaded]);
  // Prepare routines when browsing days, not just when restarting the app.
  useEffect(()=>{if(loaded)setState(s=>withNewDay(s,key));},[key,loaded]);
  const update=useCallback((fn:(s:AppState)=>AppState)=>setState(fn),[]);
  const toggleTask=(id:string)=>update(s=>({...s,tasks:s.tasks.map(t=>t.id===id?{...t,done:!t.done}:t)}));
  const collectPeas=(activityId:RewardActivityId)=>{
    const allowed=canClaim(rewardBank,activityId,todayKey);
    if(!allowed.ok){Alert.alert('Your pea bank ♡',allowed.reason||'Try again another day.');return;}
    update(s=>({...s,rewardBank:claimActivity(s.rewardBank??emptyBank(),activityId,todayKey,unique())}));
  };
  const unlockReward=(id:RewardPrizeId)=>{
    const prize=PRIZES.find(p=>p.id===id)!;
    if(rewardBank.balance<prize.points){Alert.alert('Keep collecting ♡',`You need ${prize.points-rewardBank.balance} more points for this reward.`);return;}
    Alert.alert('Redeem this reward?',`${prize.label} · ${prize.points.toLocaleString()} peas. Confirm the gift and budget together; Pea cannot purchase or guarantee it.`,[
      {text:'Not yet',style:'cancel'},
      {text:'Redeem together',onPress:()=>update(s=>({...s,rewardBank:redeemPrize(s.rewardBank??emptyBank(),id,todayKey,unique())}))},
    ]);
  };
  const undoLastPeas=()=>{
    const entry=rewardBank.entries[0];if(!entry||entry.kind!=='earn'||entry.date!==todayKey)return;
    update(s=>{
      const b=s.rewardBank??emptyBank();if(!b.entries.some(x=>x.id===entry.id))return s;
      return {...s,rewardBank:{...b,balance:Math.max(0,b.balance-entry.points),lifetimeEarned:Math.max(0,b.lifetimeEarned-entry.points),entries:b.entries.filter(x=>x.id!==entry.id)}};
    });
  };
  const confirmDeleteTask=(task:Task)=>Alert.alert('Remove this task?',task.title,[{text:'Keep',style:'cancel'},{text:'Remove',style:'destructive',onPress:()=>update(s=>({...s,tasks:s.tasks.filter(t=>t.id!==task.id)}))}]);
  const addTask=()=>{
    const title=newTitle.trim();if(!title)return;
    update(s=>({...s,tasks:[...s.tasks,{id:unique(),title,date:key,section:newSection,assignee:newAssignee,done:false}]}));
    setNewTitle('');setModal(null);
  };
  const addEvent=()=>{
    const title=newTitle.trim();if(!title)return;
    if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(eventTime)){Alert.alert('Check the time','Use 24-hour format, such as 08:30 or 15:45.');return;}
    update(s=>({...s,events:[...(s.events??[]),{id:unique(),date:key,title,time:eventTime,category:eventCategory}]}));
    setNewTitle('');setModal(null);
  };
  const addGrocery=()=>{
    const title=newTitle.trim();if(!title)return;
    update(s=>({...s,groceries:[...s.groceries,{id:unique(),title,done:false}]}));setNewTitle('');setModal(null);
  };
  const selectMeal=(kind:'lunch'|'dinner',direction=1)=>{
    const subset=meals.filter(m=>m.kind===kind);
    const now=kind==='lunch'?lunch:dinner;
    const idx=subset.findIndex(m=>m.id===now.id);
    const next=subset[(idx+direction+subset.length)%subset.length];
    update(s=>({...s,mealChoices:{...s.mealChoices,[key]:{...s.mealChoices[key],[kind]:next.id}}}));
  };
  const addMealGroceries=(meal:Meal)=>{
    update(s=>{
      const present=new Set(s.groceries.map(x=>x.title.toLowerCase()));
      const missing=meal.ingredients.filter(ingredient=>!present.has(ingredient.toLowerCase())).map(title=>({id:unique(),title,done:false}));
      return {...s,groceries:[...s.groceries,...missing]};
    });
    Alert.alert('Added to your list','Ingredients are ready in your grocery list.');
  };
  const toggleGrocery=(id:string)=>update(s=>({...s,groceries:s.groceries.map(g=>g.id===id?{...g,done:!g.done}:g)}));
  const togglePrivateToday=()=>update(s=>({...s,reminder:{...s.reminder,doneDates:hasPrivateDone?s.reminder.doneDates.filter(d=>d!==key):[...s.reminder.doneDates,key]}}));
  const openReminder=()=>{setHourValue(String(state.reminder.hour));setMinuteValue(two(state.reminder.minute));setReminderLabel(state.reminder.label);setReminderVisible(state.reminder.revealOnToday);setModal('reminder');};
  const saveReminder=async(enable:boolean)=>{
    if(notificationBusy)return;
    const hour=Number(hourValue),minute=Number(minuteValue);
    if(!Number.isInteger(hour)||hour<0||hour>23||!Number.isInteger(minute)||minute<0||minute>59){Alert.alert('Check the time','Please enter a 24-hour time such as 20 and 00.');return;}
    setNotificationBusy(true);
    try{
      let id:string|null=null;
      if(enable)id=await enablePrivateDailyNotification(hour,minute,state.reminder.notificationId);
      else await clearPrivateNotification(state.reminder.notificationId);
      update(s=>({...s,reminder:{...s.reminder,enabled:enable,label:reminderLabel.trim()||'Personal check-in',hour,minute,revealOnToday:reminderVisible,notificationId:id}}));
      setModal(null);
      Alert.alert(enable?'Private reminder is on':'Reminder is off',enable?'Your device will show a neutral daily Pea reminder.':'No personal daily notification is scheduled.');
    }catch(e){Alert.alert('Reminder could not be scheduled',e instanceof Error?e.message:'Check notification settings and try again.');}
    finally{setNotificationBusy(false);}
  };
  const openWebsite=async(url:string)=>{try{await Linking.openURL(url);}catch{Alert.alert('Unable to open link','Please try again later.');}};
  // On-demand, public-only requests. No student or household data is transmitted.
  async function refreshPicks(category:FeedCategory) {
    setPickCategory(category);setPickError('');setPickLoading(true);setLivePicks([]);
    try {const list=await getPicks(category);setLivePicks(list);setPickChecked(new Date().toISOString());}
    catch(e) {setPickError(e instanceof Error?e.message:'Internet feed unavailable.');}
    finally {setPickLoading(false);}
  }
  async function refreshWorkPolicy() {
    setRestrictionLoading(true);setNoticesLoading(true);setRestrictionError('');setNoticesError('');
    // Neither request contains the selected country, a student name, or personal data.
    await Promise.all([
      getRestrictions().then(setRestrictions).catch(e=>{
        setRestrictions(restrictionSnapshot);
        setRestrictionError(e instanceof Error?e.message:'Could not verify State Department restrictions.');
      }).finally(()=>setRestrictionLoading(false)),
      getFederalNotices().then(setNotices).catch(e=>{
        setNotices([]);setNoticesError(e instanceof Error?e.message:'Could not retrieve Federal Register updates.');
      }).finally(()=>setNoticesLoading(false)),
    ]);
  }
  useEffect(()=>{
    if(tab==='pod'&&podView==='discover'&&lastPickTry.current!==pickCategory){
      lastPickTry.current=pickCategory;refreshPicks(pickCategory);
    }
  },[tab,podView,pickCategory]);
  useEffect(()=>{
    if(tab==='work'&&workView==='policy'&&!lastWorkTry.current){
      lastWorkTry.current=true;refreshWorkPolicy();
    }
  },[tab,workView]);
  function saveSuggestedPick(pick:LivePick){
    const category: TreatCategory=pickCategory==='movie'?'movie':pickCategory==='bestsellers'?'books':pickCategory==='romance'?'romance':'thriller';
    if((state.treats??[]).some(t=>t.category===category&&t.title.toLowerCase()===pick.title.toLowerCase())){
      Alert.alert('Already saved ♡','You have this one in My Happy Place.');return;
    }
    const treat:Treat={id:unique(),category,title:pick.title,note:`${pick.subtitle} · Found via ${pick.source}`,url:pick.url,status:'saved',createdAt:new Date().toISOString()};
    update(s=>({...s,treats:[treat,...(s.treats??[])]}));
    Alert.alert('Saved to My Happy Place ♡',pick.title);
  }

  const shareGroceries=async()=>{try{await Share.share({message:'Pea grocery list ♡\n\n'+(state.groceries.filter(g=>!g.done).map(g=>'□ '+g.title).join('\n')||'Everything is checked off!')});}catch{Alert.alert('Could not share list','Try again from the grocery screen.');}};
  const shareTemplate=async()=>{try{await Share.share({message:workTemplates[selectedTemplate].body});}catch{Alert.alert('Unable to share','You can still select the template text.');}};
  const openRecipe=(meal:Meal)=>{setSelectedRecipe(meal);setModal('recipe');};
  const reset=()=>Alert.alert('Clear Pea’s plans?','This deletes tasks, meal choices and shopping lists stored on this device.',[
    {text:'Keep my plans',style:'cancel'},
    {text:'Clear local data',style:'destructive',onPress:async()=>{
      await clearPrivateNotification(state.reminder.notificationId);
      await AsyncStorage.removeItem(STORAGE_KEY);
      await SecureStore.deleteItemAsync(PRIVATE_KEY);
      setState(initialState());setTab('today');setDateOffset(0);
    }},
  ]);
  const openMeTime=(category?:TreatCategory)=>{if(category)setTreatFilter(category);setPodView('me');setTab('pod');};
  const openTreatModal=(category:TreatCategory)=>{
    setNewTreatCategory(category);setNewTreatTitle('');setNewTreatNote('');setNewTreatUrl('');setModal('treat');
  };
  const saveTreat=()=>{
    const title=newTreatTitle.trim(),url=newTreatUrl.trim();
    if(!title){Alert.alert('Give it a name','Add a book, movie, beauty item or video title.');return;}
    if(!safePersonalLink(url)){Alert.alert('Check your link','Use a full https:// link or leave the link blank.');return;}
    const treat:Treat={id:unique(),category:newTreatCategory,title,note:newTreatNote.trim(),url:url||undefined,status:'saved',createdAt:new Date().toISOString()};
    update(s=>({...s,treats:[treat,...(s.treats??[])]}));
    setTreatFilter(newTreatCategory);setModal(null);setPodView('me');setTab('pod');
  };
  const cycleTreat=(id:string)=>update(s=>({...s,treats:(s.treats??[]).map(t=>t.id===id?{...t,status:nextTreatStatus(t.status)}:t)}));
  const deleteTreat=(item:Treat)=>Alert.alert('Remove from your list?',item.title,[{text:'Keep',style:'cancel'},{text:'Remove',style:'destructive',onPress:()=>update(s=>({...s,treats:(s.treats??[]).filter(t=>t.id!==item.id)}))}]);
  const openAddEvent=()=>{setNewTitle('');setEventTime('08:00');setEventCategory('School');setModal('event');};
  const openAddTask=(section:Section='home')=>{setNewSection(section);setNewAssignee(section==='home'?'Partner':'Pankhuri');setNewTitle('');setModal('task');};

  function dayStrip(){return <View style={styles.dayStrip}>
    {Array.from({length:5},(_,i)=>i-2).map(n=>{
      const d=addDays(date,n),isSelected=n===0;
      return <Pressable key={n} onPress={()=>setDateOffset(v=>v+n)} style={[styles.dayChip,isSelected&&{backgroundColor:C.green,borderColor:C.green}]}>
        <Text style={[styles.dayWeekday,isSelected&&{color:C.white}]}>{weekdays[d.getDay()]}</Text>
        <Text style={[styles.dayNum,isSelected&&{color:C.white}]}>{d.getDate()}</Text>
      </Pressable>;
    })}
  </View>}

  function mealCard(meal:Meal,kind:'lunch'|'dinner'){
    return <Card style={{marginBottom:12,backgroundColor:kind==='lunch'?C.greenSoft:C.pinkSoft,borderWidth:0}}>
      <View style={styles.mealHeadline}><View style={{flex:1}}><TinyLabel>{kind==='lunch'?'KIDS’ LUNCH IDEA':'DINNER TONIGHT'}</TinyLabel><Text style={styles.mealName}>{meal.title}</Text><Text style={styles.meta}>{meal.minutes} min · {meal.description}</Text></View><Text style={{fontSize:42}}>{meal.emoji}</Text></View>
      <View style={styles.mealActions}><Action title="How to make" onPress={()=>openRecipe(meal)} icon="book-outline" variant="outline"/><Action title="Another" onPress={()=>selectMeal(kind)} icon="refresh-outline" variant="outline"/><Action title="Add groceries" onPress={()=>addMealGroceries(meal)} icon="basket-outline" variant="outline"/></View>
    </Card>;
  }

  // This Home screen is intentionally compact. It reflects the app layout, not a separate concept image.
  function homeScreen(){
    const prioritized=remaining.slice(0,3);
    const wisdom=dailyWisdom(todayKey);
    return <>
      <View style={styles.homeHello}>
        <View style={{flex:1}}><Text style={styles.eyebrow}>A LITTLE HELP WITH A LOT OF LIFE</Text><Text style={styles.homeGreeting}>Good morning,\nPankhuri <Text style={{color:C.pink}}>♡</Text></Text><Text style={styles.heroSub}>One little thing at a time.</Text></View>
        <Image source={POD_MARK} style={{width:94,height:82}} resizeMode="contain"/>
      </View>
      <View style={styles.quickGrid}>
        {([
          {title:'Work',desc:'Visa updates',icon:'globe-outline' as IconName,onPress:()=>{setTab('work');setWorkView('policy');}},
          {title:'Movies',desc:'Trending picks',icon:'film-outline' as IconName,onPress:()=>{setTab('pod');setPickCategory('movie');setPodView('discover');}},
          {title:'Books',desc:'Thrillers & romance',icon:'book-outline' as IconName,onPress:()=>{setTab('pod');setPickCategory('thriller');setPodView('discover');}},
          {title:'Pea Bank',desc:`${rewardBank.balance} points`,icon:'heart-outline' as IconName,onPress:()=>{setTab('pod');setPodView('rewards');}},
        ]).map((link,i)=><Pressable key={link.title} onPress={link.onPress} style={[styles.quickTile,{backgroundColor:i===1||i===3?C.pinkSoft:C.greenSoft}]} accessibilityRole="button">
          <View style={styles.quickIcon}><SmallIcon name={link.icon} size={20}/></View><Text style={styles.quickName}>{link.title}</Text><Text numberOfLines={1} style={styles.quickSub}>{link.desc}</Text>
        </Pressable>)}
      </View>
      <View style={{height:17}}/>
      <Heading title="Today at a glance" subtitle={fmtDate(date)} right={<Action title="+ Add" variant="outline" onPress={()=>openAddTask()}/>}/>
      <Card>
        {prioritized.length?prioritized.map((t,i)=><View key={t.id}>{i>0?<View style={styles.separator}/>:null}<TaskRow task={t} onToggle={()=>toggleTask(t.id)} onLongPress={()=>confirmDeleteTask(t)} compact/></View>):<Text style={styles.body}>All clear. A little breathing room is yours ♡</Text>}
        {remaining.length>3?<Pressable onPress={()=>setTab('family')} style={{paddingTop:10}}><Text style={styles.link}>See all {remaining.length} things →</Text></Pressable>:null}
      </Card>
      {state.wisdomEnabled?<Pressable style={styles.wisdomCard} onPress={()=>openWebsite(wisdom.url)} accessibilityRole="link">
        <View style={{flex:1}}><TinyLabel>✦ TODAY'S GITA REFLECTION</TinyLabel><Text style={styles.wisdomText}>{wisdom.reflection}</Text><Text style={styles.meta}>{wisdom.ref} · Original reflection, not a translation ↗</Text></View>
      </Pressable>:null}
      <Pressable onPress={()=>{setTab('pod');setPodView('rewards');}} style={styles.bankMini} accessibilityRole="button">
        <View style={styles.bankMiniIcon}><View style={styles.miniPeaCoin}><View style={styles.miniPeaShine}/></View></View>
        <View style={{flex:1}}><Text style={styles.cardTitle}>Your little pea bank ♡</Text><Text style={styles.meta}>{rewardBank.enabled?`${rewardBank.balance.toLocaleString()} points · ${thisWeekPeas}/${WEEKLY_POINTS_CAP} this week`:'Tap to start collecting peas'}</Text></View>
        <SmallIcon name="chevron-forward" size={17} color={C.muted}/>
      </Pressable>
      <View style={{height:18}}/>
      <Heading title="Make tonight easier" subtitle="Your dinner & the family reset"/>
      <View style={styles.summaryRow}>
        <Pressable onPress={()=>setTab('meals')} style={[styles.summaryTile,{backgroundColor:C.pinkSoft}]}><SmallIcon name="restaurant-outline" color={C.green}/><Text style={styles.cardTitle}>Dinner</Text><Text numberOfLines={2} style={styles.meta}>{dinner.title}</Text></Pressable>
        <Pressable onPress={()=>setTab('family')} style={[styles.summaryTile,{backgroundColor:C.greenSoft}]}><SmallIcon name="checkmark-done-outline" color={C.green}/><Text style={styles.cardTitle}>Evening reset</Text><Text style={styles.meta}>{homeCompleted}/{homeTasks.length} completed</Text></Pressable>
      </View>
      <Pressable onPress={()=>openMeTime()} style={[styles.meTimeHero,{marginTop:14}]} accessibilityRole="button"><SmallIcon name="heart-outline" color={C.pink} size={22}/><View style={{flex:1}}><Text style={styles.cardTitle}>Something just for you</Text><Text style={styles.meta}>Books · beauty · TikTok finds</Text></View><SmallIcon name="chevron-forward" size={18} color={C.muted}/></Pressable>
      {state.reminder.enabled&&state.reminder.revealOnToday?<Card style={{marginTop:13}}><TaskRow task={{id:'private',title:state.reminder.label,assignee:'Pankhuri',section:'home',date:key,done:hasPrivateDone}} onToggle={togglePrivateToday} compact/></Card>:null}
      <Text style={styles.warmFooter}>Made with love for you. ♡</Text>
    </>;
  }

  function familyScreen(){
    const personTasks=(assignee:Assignee)=>homeTasks.filter(t=>t.assignee===assignee);
    return <>
      <Heading title="The family planner ♡" subtitle="Everything the kids need, in one calm place"/>
      {dayStrip()}
      <Card style={{backgroundColor:C.greenSoft,borderWidth:0}}>
        <View style={styles.inline}><View style={{flex:1}}><TinyLabel>EVENING RESET</TinyLabel><Text style={styles.cardTitle}>A calmer tomorrow starts here</Text><Text style={styles.meta}>Lunches · dishes · backpacks · dinner</Text></View><Text style={{fontSize:40}}>🌷</Text></View>
      </Card>
      <View style={{height:17}}/>
      <Heading title="This week" subtitle="Tap a day to see its tasks and plans"/>
      <View style={styles.weekStrip}>{Array.from({length:7},(_,i)=>i).map(i=>{
        const d=addDays(new Date(),i), dk=dayKey(d), count=(state.events??[]).filter(e=>e.date===dk).length;
        return <Pressable key={dk} onPress={()=>setDateOffset(i)} style={[styles.weekDay,dk===key&&styles.weekDayActive]}>
          <Text style={[styles.weekDayName,dk===key&&{color:C.white}]}>{weekdays[d.getDay()]}</Text>
          <Text style={[styles.weekDayNum,dk===key&&{color:C.white}]}>{d.getDate()}</Text>
          <View style={[styles.eventDot,{opacity:count?1:0,backgroundColor:dk===key?C.white:C.pink}]}/>
        </Pressable>;
      })}</View>
      <View style={{height:20}}/>
      <Heading title="Family schedule" subtitle="The school events, appointments & plans that matter" right={<Action title="Add event" icon="add" variant="outline" onPress={openAddEvent}/>}/>
      <Card style={{marginBottom:21}}>{calendarEvents.length?calendarEvents.map((ev,i)=><View key={ev.id}>{i>0?<View style={styles.separator}/>:null}<View style={styles.inline}><View style={styles.calendarTime}><Text style={{color:C.green,fontSize:11,fontWeight:'700'}}>{ev.time}</Text></View><View style={{flex:1}}><Text style={styles.cardTitle}>{ev.title}</Text><Text style={styles.meta}>{ev.category}</Text></View><Pressable onPress={()=>Alert.alert('Remove this event?',ev.title,[{text:'Keep',style:'cancel'},{text:'Remove',style:'destructive',onPress:()=>update(s=>({...s,events:s.events.filter(x=>x.id!==ev.id)}))}])}><SmallIcon name="close-circle-outline" color={C.muted}/></Pressable></View></View>):<Text style={styles.meta}>No plans added for this day. Tap “Add event” for school dates, pickups or appointments.</Text>}</Card>
      <Heading title="Your side of the team" subtitle="Share the work—not just the reminders" right={<Action title="Add chore" onPress={()=>openAddTask('home')} icon="add" variant="outline"/>}/>
      <Card><View style={styles.groupHead}><SmallIcon name="heart-outline" size={17} color={C.pink}/><Text style={styles.groupTitle}>Partner’s list</Text></View>
      {personTasks('Partner').length?personTasks('Partner').map(t=><TaskRow key={t.id} task={t} onToggle={()=>toggleTask(t.id)} onLongPress={()=>confirmDeleteTask(t)}/>):<Text style={styles.meta}>Nothing assigned yet.</Text>}
      <View style={styles.separator}/><View style={styles.groupHead}><SmallIcon name="flower-outline" size={17} color={C.pink}/><Text style={styles.groupTitle}>Pankhuri’s list</Text></View>
      {personTasks('Pankhuri').length?personTasks('Pankhuri').map(t=><TaskRow key={t.id} task={t} onToggle={()=>toggleTask(t.id)} onLongPress={()=>confirmDeleteTask(t)}/>):<Text style={styles.meta}>Nothing assigned yet.</Text>}
      </Card>
      <Text style={styles.tipText}>Tip: Touch and hold a task to remove it.</Text>
      <View style={{height:8}}/>
      <Heading title="The kids’ little routines"/>
      <View style={styles.twoTiles}>
        <Card style={[styles.miniRoutine,{backgroundColor:C.pinkSoft,borderWidth:0}]}><Text style={{fontSize:30}}>🎒</Text><Text style={styles.cardTitle}>School mornings</Text><Text style={styles.meta}>Bags, lunches, water bottles</Text></Card>
        <Card style={[styles.miniRoutine,{backgroundColor:C.greenSoft,borderWidth:0}]}><Text style={{fontSize:30}}>🌙</Text><Text style={styles.cardTitle}>Evening reset</Text><Text style={styles.meta}>Kitchen clear, clothes ready</Text></Card>
      </View>
      <View style={{height:16}}/>
      <Card style={{backgroundColor:C.white}}><Text style={styles.cardTitle}>You don’t have to hold every detail.</Text><Text style={styles.body}>Give dishes and lunch prep an owner. Pea keeps the plan visible so the whole family can breathe.</Text></Card>
    </>;
  }

  function mealsScreen(){return <>
    <Heading title="Meals, without the stress" subtitle="Fewer decisions. Happier evenings."/>
    {dayStrip()}
    {mealCard(lunch,'lunch')}{mealCard(dinner,'dinner')}
    <Heading title="Grocery list" subtitle="Tap ingredients as you pick them up" right={<View style={{flexDirection:"row",gap:7}}><Action title="Share" icon="share-outline" variant="outline" onPress={shareGroceries}/><Action title="Add" icon="add" variant="outline" onPress={()=>{setNewTitle('');setModal('grocery');}}/></View>}/>
    <Card>{state.groceries.length?state.groceries.map((g,i)=><View key={g.id}>{i>0?<View style={styles.separator}/>:null}<Pressable onPress={()=>toggleGrocery(g.id)} style={styles.groceryRow}><SmallIcon name={g.done?'checkbox':'square-outline'} color={g.done?C.green:C.pink} size={23}/><Text style={[styles.taskTitle,{flex:1},g.done&&styles.strike]}>{g.title}</Text></Pressable></View>):<Text style={styles.meta}>The list is empty. Add what you need.</Text>}</Card>
    {state.groceries.some(g=>g.done)?<Pressable onPress={()=>update(s=>({...s,groceries:s.groceries.filter(g=>!g.done)}))} style={styles.textButton}><Text style={styles.link}>Remove checked items</Text></Pressable>:null}
    <Text style={styles.tipText}>Tip: Dinner leftovers can become tomorrow's lunch. Start with what you already have.</Text>
  </>}

  function workScreen(){if(workView==='policy')return policyScreen();return <>
    <Heading title="Work, a little lighter" subtitle="For newly admitted international students"/>
    <Card style={{backgroundColor:C.greenSoft,borderWidth:0}}><View style={styles.inline}><View style={{flex:1}}><TinyLabel>WORKFLOW COMPANION</TinyLabel><Text style={styles.cardTitle}>One step at a time</Text><Text style={styles.body}>Templates, checklists and official links—without copying confidential student information into Pea.</Text></View><Text style={{fontSize:42}}>💻</Text></View></Card>
    <View style={{height:20}}/>
    <Heading title="Today's work checklist" right={<Action title="Add" onPress={()=>openAddTask('work')} icon="add" variant="outline"/>}/>
    <Card>{workTasks.length?workTasks.map(t=><TaskRow key={t.id} task={t} onToggle={()=>toggleTask(t.id)} onLongPress={()=>confirmDeleteTask(t)}/>):<Text style={styles.meta}>No work tasks yet. Add a general task to get started.</Text>}</Card>
    <View style={{height:20}}/>
    <Heading title="Quick email & processing guides" subtitle="Editable examples to use in approved BU tools"/>
    {workTemplates.map((t,i)=><Card key={t.title} style={{marginBottom:10}} onPress={()=>{setSelectedTemplate(i);setModal('template');}}><View style={styles.inline}><View style={[styles.tileIcon,{backgroundColor:i===1?C.pinkSoft:C.greenSoft}]}><SmallIcon name={i===2?'list-outline':i===1?'school-outline':'mail-outline'} size={22}/></View><View style={{flex:1}}><Text style={styles.cardTitle}>{t.title}</Text><Text style={styles.meta}>{t.subtitle}</Text></View><SmallIcon name="chevron-forward" color={C.muted}/></View></Card>)}
    <View style={{height:14}}/>
    <Card style={{backgroundColor:C.pinkSoft,borderWidth:0}} onPress={()=>setWorkView('policy')}>
      <View style={styles.inline}><View style={styles.linkIcon}><SmallIcon name="globe-outline"/></View>
        <View style={{flex:1}}><Text style={styles.cardTitle}>Pea Work Watch · Live updates</Text><Text style={styles.meta}>Country restrictions, D/S, DOS & regulatory notices</Text></View>
        <SmallIcon name="chevron-forward" color={C.muted}/></View>
    </Card>
    <View style={{height:15}}/>
    <Heading title="Official work references"/>
    {officialResources.map(item=><Card key={item.url} style={{marginBottom:9}} onPress={()=>openWebsite(item.url)}><View style={styles.inline}><SmallIcon name="open-outline"/><View style={{flex:1}}><Text style={styles.cardTitle}>{item.title}</Text><Text style={styles.meta}>{item.agency}</Text></View></View></Card>)}
    <Text style={styles.tipText}>Verify country restrictions, D/S requirements and SEVIS procedures with official agencies and university-approved policies. Pea does not make immigration determinations.</Text>
  </>}

  function policyScreen(){
    const visible=restrictions.countries.filter(c=>(countryCategory==='all'||c.category===countryCategory)&&c.name.toLowerCase().includes(countrySearch.trim().toLowerCase()));
    const count=(category:CountryCategory)=>restrictions.countries.filter(c=>c.category===category).length;
    return <>
      <Pressable onPress={()=>setWorkView('main')} style={styles.backLink}><SmallIcon name="arrow-back"/><Text style={styles.link}>Back to Work</Text></Pressable>
      <Heading title="Pea Work Watch" subtitle="Official-source immigration policy reference" right={<Action title={restrictionLoading||noticesLoading?'Checking…':'Refresh'} onPress={refreshWorkPolicy} icon="refresh-outline" variant="outline"/>}/>
      <Card style={{backgroundColor:C.pinkSoft,borderWidth:0,marginBottom:12}}>
        <View style={styles.inline}><SmallIcon name="alert-circle-outline" color={C.danger} size={24}/><View style={{flex:1}}><Text style={styles.cardTitle}>D/S rule: temporarily blocked</Text><Text style={styles.body}>A September 14, 2026 federal court order postponed the fixed-admission rule. The existing D/S framework remains in effect as last reviewed October 25, 2026. Litigation and appeal are ongoing. This is NOT a live court-status determination.</Text></View></View>
        <View style={{flexDirection:'row',gap:8,marginTop:12,flexWrap:'wrap'}}><Action title="Court status" variant="outline" icon="open-outline" onPress={()=>openWebsite(URLS.durationLitigation)}/><Action title="Federal rule" variant="outline" icon="open-outline" onPress={()=>openWebsite(URLS.durationFinal)}/></View>
      </Card>
      <Heading title="Country restrictions" subtitle="U.S. Department of State · PP 10998" right={restrictionLoading?<ActivityIndicator color={C.green}/>:null}/>
      <Card style={{marginBottom:10}}>
        <Text style={styles.cardTitle}>{restrictions.countries.length} countries in {restrictions.liveVerified?'fetched DOS guidance':'published reference snapshot'}</Text>
        <Text style={styles.body}>{restrictions.liveVerified?`Government page fetched: ${new Date(restrictions.lastChecked!).toLocaleString()}`:`Snapshot published: ${restrictions.sourceDate}`}</Text>
        <Text style={[styles.tipText,{color:restrictions.liveVerified?C.green:C.danger,marginBottom:0}]}>{restrictions.liveVerified?'Fetched from official DOS page · check exceptions':'NOT live verified · use the government link before any decision'}</Text>
        {restrictionError?<Text style={[styles.body,{color:C.danger}]}>{restrictionError}</Text>:null}
        <Text style={styles.body}>{restrictions.note}</Text>
        <View style={{flexDirection:'row',gap:8,flexWrap:'wrap',marginTop:12}}><Action title="Open DOS guidance" icon="open-outline" variant="outline" onPress={()=>openWebsite(URLS.dosRestrictions)}/><Action title={showCountries?'Hide countries':'See country list'} icon="list-outline" onPress={()=>setShowCountries(v=>!v)}/></View>
      </Card>
      <View style={styles.policyCounts}>
        <View style={[styles.policyCount,{backgroundColor:C.pinkSoft}]}><Text style={styles.policyNumber}>{count('full')}</Text><Text style={styles.policyLabel}>Full visa restrictions*</Text></View>
        <View style={[styles.policyCount,{backgroundColor:C.greenSoft}]}><Text style={styles.policyNumber}>{count('student')}</Text><Text style={styles.policyLabel}>F/M/J affected*</Text></View>
        <View style={[styles.policyCount,{backgroundColor:C.pinkSoft}]}><Text style={styles.policyNumber}>{count('immigrant')}</Text><Text style={styles.policyLabel}>Immigrant-only*</Text></View>
      </View>
      <Text style={styles.tipText}>*Categories summarize DOS visa-issuance guidance, not every entry rule or exception. Turkmenistan's restriction covers immigrant visas; it is not listed as an F/M/J suspension in this proclamation.</Text>
      {showCountries?<>
        <TextInput style={[styles.input,{marginTop:0,marginBottom:10}]} placeholder="Search a country" value={countrySearch} onChangeText={setCountrySearch} placeholderTextColor={C.muted}/>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:12}} contentContainerStyle={{gap:7}}>
          {([{id:'all',name:'All'},{id:'full',name:'Full'},{id:'student',name:'F / M / J'},{id:'immigrant',name:'Immigrant only'}] as const).map(f=><Pressable key={f.id} onPress={()=>setCountryCategory(f.id)} style={[styles.interestChip,countryCategory===f.id&&{backgroundColor:C.green}]}><Text style={[styles.interestChipText,countryCategory===f.id&&{color:C.white}]}>{f.name}</Text></Pressable>)}
        </ScrollView>
        <Card style={{marginBottom:18}}>{visible.length?visible.map((c,i)=><View key={c.name}>{i>0?<View style={styles.separator}/>:null}<View style={[styles.inline,{paddingVertical:6}]}><Text style={[styles.taskTitle,{flex:1}]}>{c.name}</Text><Text style={styles.policyTag}>{c.category==='full'?'Full':c.category==='student'?'F/M/J affected':'Immigrant-only'}</Text></View></View>):<Text style={styles.meta}>No matches in this source snapshot.</Text>}</Card>
      </>:null}
      <Heading title="Recent regulatory documents" subtitle="Live query to the Federal Register · titles aren't legal advice" right={noticesLoading?<ActivityIndicator color={C.green}/>:null}/>
      {notices.length?notices.map(item=><Card key={item.id} style={{marginBottom:10}} onPress={()=>openWebsite(item.url)}><Text style={styles.cardTitle}>{item.title}</Text><Text style={styles.meta}>{item.type} · {item.published}</Text><Text style={[styles.link,{marginTop:8}]}>Read the source ↗</Text></Card>):<Card><Text style={styles.body}>{noticesError||'Checking official publications…'}</Text><Action title="Search Federal Register" variant="outline" icon="open-outline" onPress={()=>openWebsite(URLS.federalRegister)} style={{marginTop:12}}/></Card>}
      <Text style={styles.tipText}>For work reference only. Do not enter BU student records here. Confirm legal requirements with DOS, DHS, official court orders and BU-approved guidance.</Text>
    </>;
  }

  function meTimeScreen(){
    const picked=(state.treats??[]).filter(t=>t.category===treatFilter);
    const category=treatCategories.find(c=>c.id===treatFilter)!;
    const total=(state.treats??[]).length;
    return <>
      <Pressable onPress={()=>setPodView('main')} style={styles.backLink}><SmallIcon name="arrow-back" color={C.green}/><Text style={styles.link}>Back to Pea Pod</Text></Pressable>
      <Heading title="Your happy place ♡" subtitle="A little corner that’s only about you" right={<Action title="Add" onPress={()=>openTreatModal(treatFilter)} icon="add" variant="pink"/>}/>
      <Card style={{backgroundColor:C.pinkSoft,borderWidth:0,marginBottom:18}}>
        <View style={styles.inline}><Text style={{fontSize:34}}>💗</Text><View style={{flex:1}}><Text style={styles.cardTitle}>More of what you love.</Text><Text style={styles.body}>Save a book, plan a movie night, or remember that lip gloss. No chores allowed in here.</Text></View></View>
      </Card>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:18}} contentContainerStyle={{gap:8,paddingRight:8}}>
        {treatCategories.map(cat=><Pressable key={cat.id} onPress={()=>setTreatFilter(cat.id)} style={[styles.interestChip,treatFilter===cat.id&&{backgroundColor:C.green,borderColor:C.green}]}><Text style={{fontSize:15}}>{cat.emoji}</Text><Text style={[styles.interestChipText,treatFilter===cat.id&&{color:C.white}]}>{cat.name}</Text></Pressable>)}
      </ScrollView>
      <Heading title={`${category.emoji} ${category.name}`} subtitle={category.description}/>
      {picked.length?picked.map(t=><Pressable key={t.id} onLongPress={()=>deleteTreat(t)} style={[styles.card,{marginBottom:11}]} accessibilityRole="button" accessibilityHint="Long press to remove">
        <View style={styles.inline}><View style={{flex:1}}><Text style={styles.cardTitle}>{t.title}</Text>{t.note?<Text style={styles.body}>{t.note}</Text>:null}</View><Pressable onPress={()=>cycleTreat(t.id)} style={styles.statusChip}><Text style={{color:C.green,fontWeight:'700',fontSize:11}}>{treatStatusLabel(t.category,t.status)} ↻</Text></Pressable></View>
        {t.url?<Pressable onPress={()=>openWebsite(t.url!)} style={{flexDirection:'row',alignItems:'center',gap:6,marginTop:11}}><SmallIcon name="link-outline" color={C.green} size={15}/><Text style={styles.link}>Open saved link</Text></Pressable>:null}
      </Pressable>):<Card style={{backgroundColor:C.greenSoft,borderWidth:0}}><Text style={styles.cardTitle}>Your list is a blank page ♡</Text><Text style={styles.body}>Add something you're excited about. It'll stay here until you want it.</Text><View style={{marginTop:14,alignItems:'flex-start'}}><Action title={`Add to ${category.name}`} icon="add" variant="outline" onPress={()=>openTreatModal(treatFilter)}/></View></Card>}
      {treatFilter==='beauty'?<Pressable onPress={()=>openWebsite('https://www.sephora.com/')} style={styles.textButton}><Text style={styles.link}>Browse Sephora ↗</Text></Pressable>:null}
      {treatFilter==='tiktok'?<Text style={styles.tipText}>Found a video you love? Use Share → Copy link in TikTok, then paste it into Pea.</Text>:null}
      <View style={{height:15}}/><Text style={styles.warmFooter}>{total} little {total===1?'favorite':'favorites'} saved · just for you ♡</Text>
    </>;
  }

  function discoverScreen(){
    const tabs:[FeedCategory,string][]=[['movie','🎬 Movies'],['bestsellers','📚 Charts'],['thriller','🔍 Thrillers'],['romance','💕 Romance']];
    const sourceName=pickCategory==='movie'?'Simkl trending movies':pickCategory==='bestsellers'?'Apple Books bestsellers':'Open Library trending search';
    const url=pickCategory==='movie'?URLS.simklMovies:pickCategory==='bestsellers'?URLS.appleBooksCharts:pickCategory==='thriller'?'https://openlibrary.org/search?q=subject%3Athrillers&sort=trending':'https://openlibrary.org/search?q=subject%3Aromance&sort=trending';
    return <>
      <Pressable onPress={()=>setPodView('main')} style={styles.backLink}><SmallIcon name="arrow-back"/><Text style={styles.link}>Back to Pea Pod</Text></Pressable>
      <Heading title="Pea Picks ♡" subtitle="A little inspiration for your downtime" right={<Action title={pickLoading?'Loading…':'Refresh'} icon="refresh-outline" variant="outline" onPress={()=>refreshPicks(pickCategory)}/>}/>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:8,paddingRight:8}} style={{marginBottom:16}}>
        {tabs.map(([id,label])=><Pressable key={id} onPress={()=>{setPickCategory(id);}} style={[styles.interestChip,pickCategory===id&&{backgroundColor:C.green}]}><Text style={[styles.interestChipText,pickCategory===id&&{color:C.white}]}>{label}</Text></Pressable>)}
      </ScrollView>
      <Card style={{backgroundColor:C.greenSoft,borderWidth:0,marginBottom:16}}><Text style={styles.cardTitle}>{sourceName}</Text><Text style={styles.body}>{pickCategory==='movie'?'Most watched on Simkl this week':pickCategory==='bestsellers'?'US paid-book charts from Apple Books':pickCategory==='romance'?'Romance books trending among Open Library readers; spice level varies':'Thriller books trending among Open Library readers'}</Text><Text style={styles.meta}>{pickChecked&&livePicks.length?`Fetched ${new Date(pickChecked).toLocaleString()}`:'Live titles appear once loaded · internet required'}</Text></Card>
      {pickLoading?<View style={{padding:23,alignItems:'center',gap:9}}><ActivityIndicator color={C.green}/><Text style={styles.meta}>Finding little favorites…</Text></View>:pickError?<Card><Text style={styles.cardTitle}>Couldn't refresh this feed</Text><Text style={styles.body}>{pickError}</Text><Text style={styles.meta}>No old results are being presented as new.</Text><Action title="Open source" variant="outline" icon="open-outline" onPress={()=>openWebsite(url)} style={{marginTop:12}}/></Card>:livePicks.length?livePicks.map((pick,i)=><Card key={pick.id} style={{marginBottom:9}}><View style={styles.inline}>{pick.image?<Image source={{uri:pick.image}} style={styles.liveCover}/>:<View style={[styles.liveCover,{alignItems:'center',justifyContent:'center',backgroundColor:C.pinkSoft}]}><SmallIcon name={pickCategory==='movie'?'film-outline':'book-outline'} size={25}/></View>}<View style={{flex:1}}><Text style={styles.cardTitle} numberOfLines={2}>{i+1}. {pick.title}</Text><Text style={styles.meta} numberOfLines={2}>{pick.subtitle}</Text><Text style={[styles.meta,{marginTop:2}]}>{pick.source}</Text></View></View><View style={{flexDirection:'row',gap:8,marginTop:11}}><Action title="Save ♡" variant="pink" icon="heart-outline" onPress={()=>saveSuggestedPick(pick)}/><Action title="Details" variant="outline" icon="open-outline" onPress={()=>openWebsite(pick.url)}/></View></Card>):<Card><Text style={styles.body}>Select a category to explore what's popular.</Text></Card>}
      <View style={{height:14}}/>
      <Heading title="Beauty & TikTok" subtitle="Browse the sources, save your favorite finds"/>
      <View style={styles.twoTiles}><Pressable onPress={()=>openWebsite(URLS.sephora)} style={[styles.tile,{backgroundColor:C.pinkSoft,minHeight:121}]}><SmallIcon name="sparkles-outline"/><Text style={styles.cardTitle}>Sephora bestsellers</Text><Text style={styles.meta}>Shop current favorites ↗</Text></Pressable><Pressable onPress={()=>openWebsite(URLS.tiktok)} style={[styles.tile,{backgroundColor:C.greenSoft,minHeight:121}]}><SmallIcon name="videocam-outline"/><Text style={styles.cardTitle}>TikTok</Text><Text style={styles.meta}>Explore trending finds ↗</Text></Pressable></View>
      <Text style={styles.tipText}>Pea does not connect to a private TikTok/Sephora account or claim to rank their content; these open the original websites. Saved favorites stay on this phone.</Text>
    </>;
  }
  function rewardsScreen(){
    const bank=state.rewardBank??emptyBank();
    const peas=peasVisible(bank.balance);
    const currentWeek=pointsThisWeek(bank,todayKey);
    return <>
      <Pressable onPress={()=>setPodView('main')} style={styles.backLink}><SmallIcon name="arrow-back"/><Text style={styles.link}>Back to Pea Pod</Text></Pressable>
      <Heading title="Your Pea Bank ♡" subtitle="Little acts of care, little reasons to celebrate"/>
      <View style={styles.bankHero}>
        <View style={styles.bankHalo} pointerEvents="none"/>
        <View style={styles.bankHeroHeader}>
          <View style={{flex:1}}>
            <TinyLabel>YOUR LITTLE FORTUNE</TinyLabel>
            <Text style={styles.peaBalance}>{bank.balance.toLocaleString()}<Text style={styles.bankUnits}> pts</Text></Text>
            <Text style={styles.meta}>Small joys add up. Every single pea counts.</Text>
          </View>
          <Image source={POD_MARK} style={styles.bankPodArt} resizeMode="contain"/>
        </View>
        <View style={styles.weekGoalRow}>
          <Text style={styles.weekGoalText}>This week</Text><Text style={styles.weekGoalText}><Text style={{fontWeight:'800',color:C.text}}>{currentWeek}</Text> / {WEEKLY_POINTS_CAP} pts</Text>
        </View>
        <View style={styles.bankTrack}><View style={[styles.bankTrackFill,{width:`${Math.min(100,currentWeek/WEEKLY_POINTS_CAP*100)}%`}]}/></View>
        <View style={styles.glassJar} accessibilityLabel={`${bank.balance} points in Pea Bank, shown as ${peas.shown} individual pea tokens; ${peas.banked} tokens total`}>
          <View style={styles.jarRim}/>
          <View style={styles.jarShimmer} pointerEvents="none"/>
          <View style={styles.jarTopLine}><SmallIcon name="leaf-outline" size={16} color={C.green}/><Text style={styles.jarLabel}>YOUR COLLECTED PEAS</Text><Text style={styles.jarCount}>{peas.banked.toLocaleString()}</Text></View>
          <View style={styles.peaCoinWrap}>{peas.shown?Array.from({length:peas.shown},(_,i)=><View key={i} style={[styles.peaCoin,i%3===1&&{backgroundColor:'#9BB99B'},i%4===2&&{backgroundColor:'#7C9E80'}]}><View style={styles.peaShine}/></View>):<View style={styles.emptyJar}><View style={[styles.peaCoin,{opacity:.18}]}><View style={styles.peaShine}/></View><View style={[styles.peaCoin,{opacity:.13}]}><View style={styles.peaShine}/></View><Text style={[styles.meta,{marginLeft:10,flex:1}]}>Your first little peas will collect here ♡</Text></View>}</View>
          <View style={styles.jarFooter}><Text style={styles.jarFootText}>● 1 pea = {PEA_TOKEN_VALUE} points</Text><Text style={styles.jarFootText}>{peas.extra?`+${peas.extra} more saved · `:''}{peas.towardNext}/{PEA_TOKEN_VALUE} toward next</Text></View>
        </View>
        <View style={[styles.inline,{marginTop:17}]}>
          <View style={{flex:1}}><Text style={styles.cardTitle}>Collect peas</Text><Text style={styles.meta}>Turn on when you want to play.</Text></View>
          <Switch value={bank.enabled} onValueChange={enabled=>update(s=>({...s,rewardBank:{...(s.rewardBank??emptyBank()),enabled}}))} trackColor={{false:C.line,true:C.greenMid}} thumbColor={C.green}/>
        </View>
      </View>
      <View style={styles.rewardMilestoneRow}>
        <View style={[styles.milestone,{backgroundColor:C.pinkSoft}]}><SmallIcon name="cafe-outline" size={18}/><Text style={styles.milestoneNumber}>120</Text><Text style={styles.milestoneText}>Little treat</Text></View>
        <View style={[styles.milestone,{backgroundColor:C.greenSoft}]}><SmallIcon name="book-outline" size={18}/><Text style={styles.milestoneNumber}>250</Text><Text style={styles.milestoneText}>New book</Text></View>
        <View style={[styles.milestone,{backgroundColor:C.pinkSoft}]}><SmallIcon name="diamond-outline" size={18}/><Text style={styles.milestoneNumber}>5.2k</Text><Text style={styles.milestoneText}>Dream gift</Text></View>
      </View>
      <Text style={styles.tipText}>A shared, playful thank-you—not a measure of worth. No points for intimacy, affection, medical routines or obligations. Whoever participates chooses freely.</Text>
      {bank.enabled?<>
        <Heading title="Add a little pea" subtitle="Tap an activity when you choose to celebrate it" right={bank.entries[0]?.kind==='earn'&&bank.entries[0]?.date===todayKey?<Action title="Undo" variant="outline" onPress={undoLastPeas}/>:undefined}/>
        <View style={styles.rewardActivityGrid}>{ACTIVITIES.map(a=>{
          const allowed=canClaim(bank,a.id,todayKey);
          return <Pressable key={a.id} onPress={()=>collectPeas(a.id)} disabled={!allowed.ok} style={[styles.rewardActivityTile,!allowed.ok&&{opacity:.48}]} accessibilityRole="button" accessibilityLabel={`${a.label}, ${a.points} points`}>
            <View style={styles.rewardActivityIcon}><SmallIcon name={a.icon as IconName} size={21} color={C.green}/></View><Text style={styles.rewardName}>{a.label}</Text><Text style={styles.rewardPoints}>{allowed.ok?`+${allowed.award} points`:bank.entries.some(e=>e.activityId===a.id&&e.date===todayKey)?'Added today':'Weekly cap'}</Text>
          </Pressable>;
        })}</View>
        <View style={{height:17}}/>
        <Heading title="Little rewards, big smiles" subtitle="Ideas to agree on together · not automatic purchases"/>
        {PRIZES.map(prize=>{
          const remaining=Math.max(0,prize.points-bank.balance);

          return <Card key={prize.id} style={{marginBottom:10}}>
            <View style={styles.inline}><View style={[styles.linkIcon,{backgroundColor:C.pinkSoft}]}><SmallIcon name={prize.icon as IconName} size={20} color={C.green}/></View><View style={{flex:1}}><Text style={styles.cardTitle}>{prize.label}</Text><Text style={styles.meta}>{prize.estimatedCost} estimated · {prize.points.toLocaleString()} points</Text></View>{remaining===0?<Pressable onPress={()=>unlockReward(prize.id)} style={[styles.rewardRedeem,{backgroundColor:C.green}]} accessibilityRole="button"><Text style={{fontSize:11,fontWeight:'800',color:C.white}}>Redeem</Text></Pressable>:<View style={[styles.rewardRedeem,{backgroundColor:C.greenSoft}]}><Text style={{fontSize:11,fontWeight:'800',color:C.green}}>Save up</Text></View>}</View>
            <View style={styles.rewardProgressTrack}><View style={[styles.bankTrackFill,{width:`${Math.min(100,bank.balance/prize.points*100)}%`}]}/></View>
            <Text style={styles.meta}>{remaining===0?'Ready to discuss ♡':`${remaining.toLocaleString()} to go · ${projectedTimeframe(remaining).fastWeeks}–${projectedTimeframe(remaining).steadyWeeks} weeks depending on pace*`}</Text>
          </Card>;
        })}
        <Text style={styles.tipText}>*Timelines are illustrative, not guaranteed. A 5,200-point dream gift takes at least 15 weeks at the weekly cap, or around 26 weeks at 200 points/week if no other prizes are redeemed. Rewards require agreement and a real gift budget; points aren't money. ♡</Text>
      </>:<Card style={{backgroundColor:C.pinkSoft,borderWidth:0}}><Text style={styles.cardTitle}>Your bank is yours to switch on.</Text><Text style={styles.body}>Turning it on lets you save colorful pea tokens for little moments of appreciation. Nothing is required.</Text></Card>}
      {bank.entries.length?<><Heading title="Your little history" subtitle="Saved on this phone only"/><Card>{bank.entries.slice(0,8).map(e=><View key={e.id} style={[styles.inline,{paddingVertical:6}]}><Text style={[styles.body,{flex:1}]}>{e.title} · {e.date}</Text><Text style={{color:e.points>=0?C.green:C.danger,fontWeight:'700'}}>{e.points>0?'+':''}{e.points}</Text></View>)}</Card></>:null}
    </>;
  }

  function podScreen(){if(podView==='me')return meTimeScreen();if(podView==='discover')return discoverScreen();if(podView==='rewards')return rewardsScreen();return <>
    <Heading title="Pea Pod ♡" subtitle="Your cozy corner for little reminders & resources"/>
    <Card style={{backgroundColor:C.pinkSoft,borderWidth:0}}><View style={styles.inline}><Image source={POD_MARK} resizeMode="contain" style={{height:60,width:86}}/><View style={{flex:1}}><Text style={styles.cardTitle}>A little pea, just for you ♡</Text><Text style={styles.body}>Made with love for Pankhuri.</Text></View></View></Card>
    <View style={{height:13}}/>
    <Card onPress={()=>{setPodView('discover');setPickCategory('movie');}} style={{backgroundColor:C.greenSoft,borderWidth:0}}>
      <View style={styles.inline}><View style={styles.linkIcon}><SmallIcon name="sparkles-outline" color={C.green}/></View><View style={{flex:1}}><Text style={styles.cardTitle}>Pea Picks · What’s popular</Text><Text style={styles.meta}>Live movie & book discoveries ♡</Text></View><SmallIcon name="chevron-forward" color={C.muted}/></View>
    </Card>
    <View style={{height:12}}/>
    <Card style={{backgroundColor:C.pinkSoft,borderWidth:0}} onPress={()=>setPodView('rewards')}>
      <View style={styles.inline}><View style={styles.linkIcon}><SmallIcon name="heart-outline"/></View><View style={{flex:1}}><Text style={styles.cardTitle}>Pea Rewards · Your little bank ♡</Text><Text style={styles.meta}>{rewardBank.enabled?`${rewardBank.balance} points collected`:'Collect cute pea tokens for little celebrations'}</Text></View><SmallIcon name="chevron-forward" size={18} color={C.muted}/></View>
    </Card>
    <View style={{height:20}}/>
    <Heading title="Your happy place" subtitle="Books, movies, makeup & favorite finds"/>
    <View style={styles.happyGrid}>
      {treatCategories.map(cat=><Pressable key={cat.id} onPress={()=>openMeTime(cat.id)} style={[styles.happyTile,{backgroundColor:cat.id==='romance'||cat.id==='beauty'?C.pinkSoft:C.greenSoft}]}>
        <Text style={{fontSize:24}}>{cat.emoji}</Text><Text style={styles.happyTileTitle}>{cat.name}</Text>
        <Text style={styles.meta}>{(state.treats??[]).filter(t=>t.category===cat.id).length} saved</Text>
      </Pressable>)}
    </View>
    <View style={{height:22}}/>
    <Heading title="A moment of wisdom" subtitle="Inspired by the Bhagavad Gita · optional"/>
    <Card style={{backgroundColor:C.greenSoft,borderWidth:0,marginBottom:17}}>
      <View style={styles.inline}><View style={{flex:1}}><Text style={styles.cardTitle}>{dailyWisdom(todayKey).ref}</Text><Text style={styles.body}>{dailyWisdom(todayKey).reflection}</Text><Pressable onPress={()=>openWebsite(dailyWisdom(todayKey).url)} style={{marginTop:9}}><Text style={styles.link}>Read the original verse ↗</Text></Pressable></View><Switch value={state.wisdomEnabled} onValueChange={wisdomEnabled=>update(s=>({...s,wisdomEnabled}))} thumbColor={C.green} trackColor={{false:C.line,true:C.greenMid}}/></View>
      <Text style={styles.meta}>A brief original reflection based on the cited verse, not a direct translation.</Text>
    </Card>
    <Heading title="Private reminders" subtitle="Only you decide what to track"/>
    <Card onPress={openReminder}><View style={styles.inline}><View style={[styles.linkIcon,{backgroundColor:C.pinkSoft}]}><SmallIcon name="notifications-outline"/></View><View style={{flex:1}}><Text style={styles.cardTitle}>Daily personal check-in</Text><Text style={styles.meta}>{state.reminder.enabled?`On · ${friendlyTime(state.reminder.hour,state.reminder.minute)}`:'Off · tap to set up'}</Text></View><SmallIcon name="chevron-forward" color={C.muted}/></View></Card>
    {state.reminder.enabled?<Card style={{marginTop:12,backgroundColor:C.greenSoft,borderWidth:0}}><View style={styles.inline}><View style={{flex:1}}><Text style={styles.cardTitle}>{state.reminder.label}</Text><Text style={styles.meta}>{hasPrivateDone?'Done for today ♡':'Your check-in for today'}</Text></View><Pressable onPress={togglePrivateToday} style={{padding:9}}><SmallIcon name={hasPrivateDone?'checkmark-circle':'ellipse-outline'} size={27} color={hasPrivateDone?C.green:C.pink}/></Pressable></View></Card>:null}
    <View style={{height:20}}/>
    <View style={{height:15}}/>
    <Heading title="Made to feel peaceful"/>
    <Card><View style={styles.inline}><SmallIcon name="lock-closed-outline"/><View style={{flex:1}}><Text style={styles.cardTitle}>Private by default</Text><Text style={styles.body}>Your plans and saved favorites remain on this device. Public internet feeds fetch trending titles and official policies without sending student records or personal reminder details. No accounts, analytics or advertising.</Text></View></View><View style={styles.separator}/><View style={styles.inline}><SmallIcon name="shield-checkmark-outline"/><View style={{flex:1}}><Text style={styles.cardTitle}>No student records</Text><Text style={styles.body}>Do not enter student names, passport numbers, immigration records or BU credentials here.</Text></View></View></Card>
    <Pressable style={styles.textButton} onPress={reset}><Text style={{color:C.danger,fontWeight:'600'}}>Clear locally saved plans</Text></Pressable>
    <Text style={styles.warmFooter}>pea. · Made with love ♡</Text>
  </>}

  function treatModal(){return <>
    <Text style={styles.modalTitle}>Save a little favorite ♡</Text><Text style={styles.modalSub}>A book, movie, makeup find or TikTok you'll want to remember.</Text>
    <TinyLabel>ADD TO YOUR LIST</TinyLabel>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:16}} contentContainerStyle={{gap:7}}>
      {treatCategories.map(cat=><Pressable key={cat.id} onPress={()=>setNewTreatCategory(cat.id)} style={[styles.interestChip,newTreatCategory===cat.id&&{backgroundColor:C.green,borderColor:C.green}]}><Text style={[styles.interestChipText,newTreatCategory===cat.id&&{color:C.white}]}>{cat.emoji} {cat.name}</Text></Pressable>)}
    </ScrollView>
    <TinyLabel>NAME *</TinyLabel><TextInput style={styles.input} placeholder="Book, movie, product or video" placeholderTextColor={C.muted} autoFocus maxLength={120} value={newTreatTitle} onChangeText={setNewTreatTitle}/>
    <TinyLabel>YOUR NOTE (OPTIONAL)</TinyLabel><TextInput style={[styles.input,{minHeight:72,textAlignVertical:'top'}]} multiline placeholder="Why you saved it, shade name, a recommendation…" placeholderTextColor={C.muted} value={newTreatNote} onChangeText={setNewTreatNote} maxLength={300}/>
    <TinyLabel>LINK (OPTIONAL)</TinyLabel><TextInput style={styles.input} keyboardType="url" autoCapitalize="none" autoCorrect={false} placeholder="https://…" placeholderTextColor={C.muted} value={newTreatUrl} onChangeText={setNewTreatUrl} maxLength={600}/>
    <Action title="Save to my happy place" icon="heart-outline" onPress={saveTreat}/>
    <Text style={styles.tipText}>Private, local-only favorites. Tap a status to change it; long-press a saved item to remove it.</Text>
  </>}

  function recipeModal(){
    const m=selectedRecipe;
    const steps=recipeSteps[m.id]??['Gather all ingredients and prep the vegetables.','Cook ingredients thoroughly using your preferred recipe or package directions.','Serve and pack any leftovers safely.'];
    return <>
      <View style={styles.recipeHero}><Text style={{fontSize:44}}>{m.emoji}</Text><View style={{flex:1}}><TinyLabel>{m.kind==='lunch'?'LUNCHBOX IDEA':'DINNER IDEA'}</TinyLabel><Text style={styles.modalTitle}>{m.title}</Text><Text style={styles.meta}>{m.minutes} minutes · {m.description}</Text></View></View>
      <Heading title="What you’ll need"/><Card style={{marginBottom:16}}>{m.ingredients.map((item,i)=><Text key={i} style={[styles.taskTitle,{paddingVertical:5}]}>• {item}</Text>)}</Card>
      <Heading title="Simple steps"/><Card>{steps.map((step,i)=><View key={i} style={{flexDirection:'row',gap:12,marginVertical:7}}><View style={styles.stepNumber}><Text style={{color:C.white,fontWeight:'700'}}>{i+1}</Text></View><Text style={[styles.body,{flex:1,marginTop:1}]}>{step}</Text></View>)}</Card>
      <Action title="Add ingredients to groceries" icon="basket-outline" onPress={()=>{addMealGroceries(m);setModal(null);}} style={{marginTop:16}}/>
      <Text style={styles.tipText}>Double-check allergens, safe cooking temperatures and your children’s food needs before preparing.</Text>
    </>;
  }

  function taskModal(){return <>
    <Text style={styles.modalTitle}>Add one little thing</Text><Text style={styles.modalSub}>Make it easy to see who handles what.</Text>
    <TextInput style={styles.input} placeholder="What needs to get done?" placeholderTextColor={C.muted} value={newTitle} onChangeText={setNewTitle} autoFocus maxLength={100} returnKeyType="done" onSubmitEditing={addTask}/>
    <TinyLabel>THIS BELONGS TO</TinyLabel><View style={styles.choiceRow}>{(['home','work'] as Section[]).map(v=><Pressable key={v} onPress={()=>{setNewSection(v);if(v==='work')setNewAssignee('Pankhuri');}} style={[styles.choice,pill(newSection===v)]}><Text style={[styles.choiceText,newSection===v&&{color:C.white}]}>{v==='home'?'🏡 Home':'💻 Work'}</Text></Pressable>)}</View>
    <TinyLabel>WHO'S TAKING CARE OF IT?</TinyLabel><View style={styles.choiceRow}>{(['Partner','Pankhuri'] as Assignee[]).map(v=><Pressable key={v} onPress={()=>setNewAssignee(v)} style={[styles.choice,pill(newAssignee===v)]}><Text style={[styles.choiceText,newAssignee===v&&{color:C.white}]}>{v==='Partner'?'My partner':v}</Text></Pressable>)}</View>
    <Action title="Add to the day" icon="add-circle-outline" onPress={addTask} style={{marginTop:20}}/>
  </>}

  function eventModal(){return <>
    <Text style={styles.modalTitle}>A date to remember</Text><Text style={styles.modalSub}>{fmtDate(date)} · Keep the family's plans together.</Text>
    <TinyLabel>WHAT'S HAPPENING?</TinyLabel><TextInput style={styles.input} placeholder="School concert, pickup, appointment..." placeholderTextColor={C.muted} value={newTitle} onChangeText={setNewTitle} maxLength={100} autoFocus/>
    <TinyLabel>TIME (24-HOUR FORMAT)</TinyLabel><TextInput style={styles.input} value={eventTime} onChangeText={setEventTime} placeholder="15:30" placeholderTextColor={C.muted} maxLength={5} keyboardType="numbers-and-punctuation"/>
    <TinyLabel>TYPE</TinyLabel><View style={styles.choiceRow}>{(['School','Family','Appointment'] as FamilyEvent['category'][]).map(v=><Pressable key={v} onPress={()=>setEventCategory(v)} style={[styles.choice,pill(eventCategory===v)]}><Text style={[styles.choiceText,eventCategory===v&&{color:C.white}]}>{v}</Text></Pressable>)}</View>
    <Action title="Save event" icon="calendar-outline" onPress={addEvent}/>
  </>}

  function reminderModal(){return <>
    <Text style={styles.modalTitle}>A private daily reminder ♡</Text><Text style={styles.modalSub}>For medicine, vitamins or anything personal. Optional, private and fully controlled by you.</Text>
    <View style={styles.privacyCallout}><SmallIcon name="lock-closed" size={19}/><Text style={[styles.body,{flex:1}]}>Phone notifications will simply say “Your private daily check-in is ready.” No medication names are shown.</Text></View>
    <TinyLabel>YOUR PRIVATE LABEL (INSIDE PEA ONLY)</TinyLabel>
    <TextInput style={styles.input} value={reminderLabel} onChangeText={setReminderLabel} placeholder="Personal check-in" placeholderTextColor={C.muted} maxLength={50}/>
    <TinyLabel>REMIND ME AT (24-HOUR TIME)</TinyLabel>
    <View style={styles.timeRow}><TextInput style={[styles.input,styles.timeInput]} keyboardType="number-pad" maxLength={2} value={hourValue} onChangeText={setHourValue} selectTextOnFocus/><Text style={styles.timeColon}>:</Text><TextInput style={[styles.input,styles.timeInput]} keyboardType="number-pad" maxLength={2} value={minuteValue} onChangeText={setMinuteValue} selectTextOnFocus/><Text style={styles.meta}>e.g. 20:00 = 8 PM</Text></View>
    <View style={styles.inline}><View style={{flex:1}}><Text style={styles.cardTitle}>Show this on Today?</Text><Text style={styles.meta}>Off keeps the reminder out of the dashboard</Text></View><Switch value={reminderVisible} onValueChange={setReminderVisible} trackColor={{false:C.line,true:C.greenMid}} thumbColor={C.green}/></View>
    {notificationBusy?<ActivityIndicator color={C.green} style={{marginTop:14}}/>:<>
      <Action title={state.reminder.enabled?'Save reminder':'Turn on my reminder'} icon="notifications-outline" onPress={()=>saveReminder(true)} style={{marginTop:20}}/>
      {state.reminder.enabled?<Action title="Turn off reminder" variant="outline" onPress={()=>saveReminder(false)} style={{marginTop:10}}/>:null}
    </>}
    <Text style={styles.tipText}>Pea is a simple reminder, not a medical device. If a dose is missed, follow the medicine's instructions or ask a clinician or pharmacist.</Text>
  </>}

  const tabs:{id:Tab;name:string;icon:IconName;active:IconName}[]=[
    {id:'today',name:'Home',icon:'home-outline',active:'home'},
    {id:'family',name:'Planner',icon:'calendar-outline',active:'calendar'},
    {id:'meals',name:'Meals',icon:'restaurant-outline',active:'restaurant'},
    {id:'work',name:'Work',icon:'briefcase-outline',active:'briefcase'},
    {id:'pod',name:'Pea Pod',icon:'leaf-outline',active:'leaf'},
  ];
  return <SafeAreaProvider><SafeAreaView style={styles.safe} edges={['top','bottom']}><StatusBar barStyle="dark-content" backgroundColor={C.bg}/>
    <View style={styles.topBar}><View style={styles.brand}><Image source={POD_MARK} resizeMode="contain" style={styles.brandImage}/><Image source={PEA_WORDMARK} resizeMode="contain" style={styles.brandWordmark} accessibilityLabel="pea."/></View><Text style={styles.topTag}>made just for you ♡</Text><Pressable onPress={()=>{setPodView('main');setTab('pod');}} style={styles.avatar}><SmallIcon name="person-outline" size={19}/></Pressable></View>
    {!loaded?<View style={styles.loading}><ActivityIndicator size="large" color={C.green}/><Text style={styles.meta}>Opening Pea...</Text></View>:
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {tab==='today'?homeScreen():tab==='family'?familyScreen():tab==='meals'?mealsScreen():tab==='work'?workScreen():podScreen()}
      </ScrollView>}
    <View style={styles.bottomTabs}>{tabs.map(t=><Pressable key={t.id} style={styles.tab} onPress={()=>{if(t.id==='pod')setPodView('main');setTab(t.id);}} accessibilityRole="tab" accessibilityState={{selected:tab===t.id}}><View style={tab===t.id?styles.activeTabIcon:styles.inactiveTabIcon}>{t.id==='pod'?<Image source={POD_MARK} resizeMode="contain" style={{width:33,height:25}}/>:<SmallIcon name={tab===t.id?t.active:t.icon} size={20} color={tab===t.id?C.green:C.muted}/>}</View><Text style={[styles.tabText,tab===t.id&&{color:C.green,fontWeight:'700'}]}>{t.name}</Text></Pressable>)}</View>
    <Modal visible={modal!==null} animationType="slide" transparent onRequestClose={()=>setModal(null)}><KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={styles.modalBackdrop}><Pressable onPress={()=>setModal(null)} style={styles.modalCurtain}/><View style={styles.modalSheet}>
      <View style={styles.modalBar}/><View style={styles.modalTop}><Image source={PEA_WORDMARK} resizeMode="contain" style={{width:82,height:34}} accessibilityLabel="pea."/><Pressable onPress={()=>setModal(null)} style={styles.close}><SmallIcon name="close"/></Pressable></View>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{paddingBottom:35}} showsVerticalScrollIndicator={false}>
        {modal==='treat'?treatModal():modal==='task'?taskModal():modal==='event'?eventModal():modal==='recipe'?recipeModal():modal==='grocery'?<><Text style={styles.modalTitle}>Add to your grocery list</Text><TextInput style={styles.input} placeholder="What do you need?" placeholderTextColor={C.muted} value={newTitle} onChangeText={setNewTitle} autoFocus returnKeyType="done" onSubmitEditing={addGrocery}/><Action title="Add ingredient" onPress={addGrocery} icon="add"/></>:modal==='reminder'?reminderModal():modal==='template'?<><Text style={styles.modalTitle}>{workTemplates[selectedTemplate].title}</Text><Text style={styles.modalSub}>Sample wording; verify and customize before using in authorized university systems.</Text><View style={styles.template}><Text selectable style={styles.templateText}>{workTemplates[selectedTemplate].body}</Text></View><Action title="Share draft" icon="share-outline" variant="outline" onPress={shareTemplate} style={{marginTop:12}}/><Text style={styles.tipText}>Review the draft before using it in BU-approved systems. Do not put student details in Pea.</Text></>:null}
      </ScrollView>
    </View></KeyboardAvoidingView></Modal>
  </SafeAreaView></SafeAreaProvider>;
}

const styles=StyleSheet.create({
  homeHello:{flexDirection:'row',alignItems:'center',minHeight:102,marginBottom:16,paddingHorizontal:2,gap:9},
  homeGreeting:{fontSize:29,lineHeight:35,fontFamily:Platform.OS==='ios'?'System':'sans-serif',fontWeight:'700',letterSpacing:-1.0,color:C.text},
  quickGrid:{flexDirection:'row',gap:8},
  quickTile:{flex:1,minWidth:0,borderRadius:19,paddingHorizontal:7,paddingVertical:13,alignItems:'center',justifyContent:'center',minHeight:98,gap:5,borderWidth:1,borderColor:'rgba(98,127,104,0.07)'},
  quickIcon:{height:38,width:38,borderRadius:13,backgroundColor:C.white,alignItems:'center',justifyContent:'center'},
  quickName:{fontSize:11.5,fontWeight:'700',color:C.text},
  quickSub:{fontSize:9.5,color:C.muted,textAlign:'center'},
  wisdomCard:{backgroundColor:C.pinkSoft,borderRadius:21,padding:17,marginTop:17,borderWidth:1,borderColor:'#F8E5E9'},
  wisdomText:{color:C.text,fontSize:14.5,lineHeight:23,fontWeight:'500',marginBottom:2},
  bankMini:{flexDirection:'row',alignItems:'center',padding:13,borderRadius:20,marginTop:14,borderWidth:1,borderColor:C.line,backgroundColor:C.white,gap:12,...shadow},
  bankMiniIcon:{height:44,width:44,borderRadius:16,backgroundColor:C.greenSoft,alignItems:'center',justifyContent:'center'},
  miniPeaCoin:{height:25,width:25,borderRadius:13,backgroundColor:C.green,borderWidth:1,borderColor:'#8EB197'},
  miniPeaShine:{height:7,width:8,borderRadius:4,backgroundColor:'#C5E1C9',marginLeft:5,marginTop:5},
  summaryRow:{flexDirection:'row',gap:10},
  summaryTile:{flex:1,borderRadius:19,padding:15,minHeight:113,gap:6},
  peaBalance:{fontSize:41,fontWeight:'800',letterSpacing:-1.7,color:C.text},
  bankUnits:{fontSize:15,fontWeight:'600',letterSpacing:0,color:C.muted},
  bankHero:{backgroundColor:C.greenSoft,padding:19,borderRadius:28,marginBottom:12,overflow:'hidden',borderWidth:1,borderColor:C.greenMid},
  bankHalo:{width:170,height:170,borderRadius:85,position:'absolute',right:-60,top:-80,backgroundColor:'rgba(255,255,255,0.40)'},
  bankHeroHeader:{flexDirection:'row',alignItems:'center',minHeight:89,gap:5},
  bankPodArt:{width:93,height:83},
  weekGoalRow:{flexDirection:'row',justifyContent:'space-between',marginTop:9},
  weekGoalText:{fontSize:12,color:C.muted,fontWeight:'600'},
  bankTrack:{marginTop:9,height:7,borderRadius:5,backgroundColor:'#FFFFFF',overflow:'hidden'},
  bankTrackFill:{height:'100%',backgroundColor:C.green,borderRadius:8},
  glassJar:{marginTop:21,minHeight:165,borderRadius:25,borderWidth:1.5,borderColor:'#B9D2BE',backgroundColor:'rgba(255,255,255,0.72)',padding:14,paddingTop:18,overflow:'hidden',...shadow},
  jarRim:{position:'absolute',top:0,left:46,right:46,height:7,borderBottomLeftRadius:12,borderBottomRightRadius:12,backgroundColor:'#BED2C2'},
  jarShimmer:{position:'absolute',top:35,bottom:29,width:14,left:9,borderRadius:8,backgroundColor:'rgba(255,255,255,0.55)'},
  jarTopLine:{flexDirection:'row',alignItems:'center',gap:7,marginBottom:13},
  jarLabel:{color:C.green,fontSize:10,fontWeight:'800',letterSpacing:1.15,flex:1},
  jarCount:{fontSize:15,fontWeight:'800',color:C.green},
  peaCoinWrap:{flexDirection:'row',flexWrap:'wrap',gap:6,minHeight:46,alignItems:'center',justifyContent:'flex-start',paddingBottom:12},
  peaCoin:{width:25,height:25,borderRadius:13,backgroundColor:C.green,borderWidth:1.5,borderColor:'#71977C',alignItems:'flex-start',shadowColor:'#3D7450',shadowOffset:{width:1,height:2},shadowOpacity:.18,shadowRadius:3,elevation:2},
  peaShine:{width:7,height:6,borderRadius:5,backgroundColor:'#D4EBD8',marginLeft:4,marginTop:4},
  emptyJar:{flexDirection:'row',alignItems:'center',paddingVertical:8},
  jarFooter:{flexDirection:'row',justifyContent:'space-between',borderTopWidth:1,borderTopColor:'#DFE9DF',paddingTop:9,gap:7},
  jarFootText:{fontSize:10,color:C.muted,fontWeight:'600'},
  rewardMilestoneRow:{flexDirection:'row',gap:9,marginTop:5,marginBottom:13},
  milestone:{flex:1,minHeight:95,borderRadius:18,padding:12,justifyContent:'space-between',gap:2},
  milestoneNumber:{fontSize:19,fontWeight:'800',color:C.text,letterSpacing:-.5},
  milestoneText:{fontSize:11,color:C.muted,fontWeight:'600'},
  rewardActivityGrid:{flexDirection:'row',flexWrap:'wrap',gap:9,marginBottom:9},
  rewardActivityTile:{width:'48%',minHeight:115,borderRadius:20,padding:13,backgroundColor:C.white,borderWidth:1,borderColor:C.line,gap:6,...shadow},
  rewardActivityIcon:{height:35,width:35,borderRadius:12,backgroundColor:C.greenSoft,alignItems:'center',justifyContent:'center'},
  rewardName:{fontSize:13,fontWeight:'700',color:C.text},
  rewardPoints:{fontSize:11.5,fontWeight:'800',color:C.green},
  rewardRedeem:{paddingHorizontal:12,paddingVertical:9,borderRadius:13},
  rewardProgressTrack:{height:6,borderRadius:6,backgroundColor:C.greenSoft,overflow:'hidden',marginTop:13,marginBottom:6},
  safe:{flex:1,backgroundColor:C.bg},
  topBar:{height:64,paddingHorizontal:21,flexDirection:'row',alignItems:'center',borderBottomColor:C.line,borderBottomWidth:1,backgroundColor:C.white},
  brand:{flexDirection:'row',alignItems:'center',gap:1},brandImage:{width:48,height:39},brandWordmark:{width:75,height:32},brandText:{fontSize:32,fontFamily:Platform.OS==='ios'?'System':'sans-serif',color:C.text,letterSpacing:-1.4},
  topTag:{fontSize:11,color:C.muted,flex:1,textAlign:'right',marginRight:13},avatar:{height:34,width:34,borderRadius:17,backgroundColor:C.greenSoft,alignItems:'center',justifyContent:'center'},
  scrollContent:{paddingHorizontal:19,paddingTop:19,paddingBottom:45},loading:{flex:1,alignItems:'center',justifyContent:'center',gap:14},
  hero:{minHeight:130,flexDirection:'row',alignItems:'center',paddingHorizontal:4,marginBottom:22},
  eyebrow:{fontSize:10,color:C.green,fontWeight:'800',letterSpacing:2,marginBottom:12},
  greeting:{fontSize:32,lineHeight:40,color:C.text,fontFamily:Platform.OS==='ios'?'System':'sans-serif'},
  heroSub:{fontSize:13,color:C.muted,lineHeight:20,marginTop:7,maxWidth:240},heroPea:{height:100,width:125},
  headingRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:12,gap:8},
  heading:{fontSize:22,lineHeight:28,color:C.text,fontWeight:'700',letterSpacing:-.65,fontFamily:Platform.OS==='ios'?'System':'sans-serif'},
  subheading:{fontSize:12.5,color:C.muted,marginTop:5,lineHeight:18},
  twoTiles:{flexDirection:'row',gap:11},tile:{flex:1,padding:17,borderRadius:22,minHeight:154,alignItems:'flex-start',gap:6},
  tileIcon:{height:38,width:38,backgroundColor:C.white,borderRadius:13,alignItems:'center',justifyContent:'center',marginBottom:3},
  tileTitle:{fontFamily:Platform.OS==='ios'?'System':'sans-serif',fontSize:21,color:C.text},tileSub:{fontSize:12,color:C.muted,marginBottom:5},
  card:{padding:17,borderRadius:22,backgroundColor:C.white,borderWidth:1,borderColor:C.line,...shadow},
  cardTitle:{fontSize:15,fontWeight:'700',color:C.text,lineHeight:21},body:{fontSize:13.5,color:C.muted,lineHeight:20,marginTop:5},
  tinyLabel:{fontSize:10,fontWeight:'800',color:C.green,letterSpacing:1.1,marginBottom:8},
  taskRow:{flexDirection:'row',alignItems:'center',gap:12,paddingVertical:12,minHeight:44},taskTitle:{fontSize:14,color:C.text,fontWeight:'500',lineHeight:20},
  strike:{textDecorationLine:'line-through',color:C.muted},meta:{fontSize:12,color:C.muted,lineHeight:18,marginTop:3},separator:{height:1,backgroundColor:C.line,marginVertical:5},
  empty:{flexDirection:'row',alignItems:'center',gap:10},link:{color:C.green,fontWeight:'700',fontSize:13},
  action:{flexDirection:'row',alignItems:'center',justifyContent:'center',paddingHorizontal:14,paddingVertical:11,borderRadius:99,gap:6},
  actionText:{fontSize:12,fontWeight:'700'},smallRound:{height:38,width:38,borderRadius:18,backgroundColor:C.greenSoft,justifyContent:'center',alignItems:'center'},
  mealHeadline:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:6},mealName:{fontSize:20,color:C.text,fontFamily:Platform.OS==='ios'?'System':'sans-serif',marginBottom:2},
  mealActions:{flexDirection:'row',gap:8,marginTop:16,flexWrap:'wrap'},
  warmFooter:{fontFamily:Platform.OS==='ios'?'System':'sans-serif',fontStyle:'italic',color:C.pink,fontSize:16,textAlign:'center',marginTop:27,marginBottom:12},
  dayStrip:{flexDirection:'row',justifyContent:'space-between',gap:7,marginBottom:15},dayChip:{flex:1,alignItems:'center',borderRadius:14,borderWidth:1,borderColor:C.line,backgroundColor:C.white,paddingVertical:10},
  dayWeekday:{fontSize:11,color:C.muted,marginBottom:4},dayNum:{fontSize:16,color:C.text,fontWeight:'700'},
  inline:{flexDirection:'row',alignItems:'center',gap:12},groupHead:{flexDirection:'row',alignItems:'center',gap:7,marginVertical:8},groupTitle:{fontSize:14,fontWeight:'700',color:C.text},
  miniRoutine:{flex:1,minHeight:144,justifyContent:'center',gap:8},groceryRow:{flexDirection:'row',alignItems:'center',gap:12,paddingVertical:10},
  progressCard:{backgroundColor:C.greenSoft,borderRadius:22,padding:15,flexDirection:'row',alignItems:'center',gap:12},
  progressRing:{height:65,width:65,borderRadius:33,borderWidth:5,borderColor:C.greenMid,alignItems:'center',justifyContent:'center',backgroundColor:C.white},
  progressText:{fontWeight:'800',color:C.green,fontSize:14},
  weekStrip:{flexDirection:'row',gap:4,marginBottom:4},weekDay:{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:C.white,borderRadius:14,paddingVertical:10,gap:3},
  weekDayActive:{backgroundColor:C.green},weekDayName:{fontSize:10,color:C.muted},weekDayNum:{fontSize:15,fontWeight:'700',color:C.text},eventDot:{height:5,width:5,borderRadius:3},
  recipeHero:{flexDirection:'row',gap:14,alignItems:'center',backgroundColor:C.pinkSoft,padding:15,borderRadius:18,marginBottom:21},
  stepNumber:{height:24,width:24,borderRadius:12,backgroundColor:C.green,alignItems:'center',justifyContent:'center'},
  calendarTime:{paddingHorizontal:9,paddingVertical:9,borderRadius:10,backgroundColor:C.greenSoft},
  textButton:{alignSelf:'center',marginTop:21,marginBottom:7,padding:8},tipText:{fontSize:12,color:C.muted,lineHeight:18,marginTop:15,marginBottom:12},
  linkIcon:{height:41,width:41,borderRadius:14,backgroundColor:C.greenSoft,alignItems:'center',justifyContent:'center'},
  bottomTabs:{height:72,flexDirection:'row',backgroundColor:C.white,borderTopColor:C.line,borderTopWidth:1,paddingTop:8},
  tab:{flex:1,alignItems:'center',justifyContent:'center'},activeTabIcon:{width:39,height:32,borderRadius:14,alignItems:'center',justifyContent:'center',backgroundColor:C.greenSoft},inactiveTabIcon:{width:40,height:33,alignItems:'center',justifyContent:'center'},
  tabText:{fontSize:10,color:C.muted,marginTop:2},
  modalBackdrop:{flex:1,justifyContent:'flex-end',backgroundColor:'rgba(33,43,34,.36)'},modalCurtain:{flex:1},
  modalSheet:{maxHeight:'84%',backgroundColor:C.bg,borderTopLeftRadius:28,borderTopRightRadius:28,paddingHorizontal:22,paddingTop:9},
  modalBar:{width:44,height:5,borderRadius:9,backgroundColor:C.pinkMid,alignSelf:'center',marginBottom:10},modalTop:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:15},
  modalBrand:{fontFamily:Platform.OS==='ios'?'System':'sans-serif',fontSize:24,color:C.green},close:{height:32,width:32,borderRadius:16,backgroundColor:C.greenSoft,alignItems:'center',justifyContent:'center'},
  modalTitle:{fontSize:25,fontFamily:Platform.OS==='ios'?'System':'sans-serif',color:C.text,marginBottom:7},modalSub:{fontSize:13.5,color:C.muted,lineHeight:21,marginBottom:16},
  input:{backgroundColor:C.white,borderWidth:1,borderColor:C.line,borderRadius:15,padding:15,color:C.text,fontSize:15,marginTop:8,marginBottom:18},
  choiceRow:{flexDirection:'row',gap:8,marginBottom:16},choice:{paddingHorizontal:15,paddingVertical:11,borderRadius:99,borderWidth:1},choiceText:{color:C.text,fontWeight:'600',fontSize:13},
  privacyCallout:{padding:13,borderRadius:15,backgroundColor:C.greenSoft,flexDirection:'row',gap:11,alignItems:'flex-start',marginBottom:15},
  timeRow:{flexDirection:'row',alignItems:'center',gap:8},timeInput:{width:65,textAlign:'center',fontSize:18},timeColon:{fontSize:22,color:C.text,marginBottom:9},
  meTimeHero:{padding:15,backgroundColor:C.pinkSoft,borderRadius:22,flexDirection:'row',alignItems:'center',gap:12},
  policyCounts:{flexDirection:'row',gap:7,marginBottom:8},
  policyCount:{flex:1,padding:11,borderRadius:15,alignItems:'center',minHeight:85,justifyContent:'center'},
  policyNumber:{fontSize:24,fontWeight:'800',color:C.text},
  policyLabel:{fontSize:10.5,color:C.muted,textAlign:'center',marginTop:4},
  policyTag:{fontSize:10.5,fontWeight:'600',color:C.green,paddingHorizontal:8,paddingVertical:6,backgroundColor:C.greenSoft,borderRadius:12},
  liveCover:{height:72,width:54,borderRadius:8,backgroundColor:C.greenSoft},
  backLink:{flexDirection:'row',alignItems:'center',gap:7,marginBottom:18,paddingVertical:5},
  happyGrid:{flexDirection:'row',flexWrap:'wrap',gap:9},
  happyTile:{width:'48%',borderRadius:19,padding:14,minHeight:105,gap:3},
  happyTileTitle:{fontSize:14,fontWeight:'700',color:C.text,marginTop:3},
  interestChip:{flexDirection:'row',alignItems:'center',gap:5,paddingHorizontal:13,paddingVertical:11,borderRadius:99,backgroundColor:C.white,borderWidth:1,borderColor:C.line},
  interestChipText:{fontSize:12,fontWeight:'700',color:C.text},
  statusChip:{paddingHorizontal:10,paddingVertical:8,borderRadius:99,backgroundColor:C.greenSoft,maxWidth:120},
  template:{padding:17,backgroundColor:C.white,borderRadius:18,borderWidth:1,borderColor:C.line},templateText:{fontSize:14,color:C.text,lineHeight:23},
});

export default Main;
