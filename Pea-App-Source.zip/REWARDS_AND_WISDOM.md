# Pea v1.5 — Rewards & Daily Wisdom

## More attainable Pea Bank

Pea is a voluntary appreciation game, not a chore-enforcement system.

- **360 points/week maximum**. A single activity can be added once per calendar day; points earned remain banked after the week resets.
- **20 points = one visible pea token**; Pea Bank shows individual pea tokens in a soft glass-style jar with a numerical total for the remaining peas.
- **Typical 200 points/week** is an illustration only; there is no guaranteed pace.
- Larger rewards take longer and require the couple to agree on gift budget and redemption. Pea does not make purchases, access financial accounts or promise gifts.
- No reward points for sex, pressured affection, or health/medication choices. Taking time to rest earns points too.

| Reward | Points | Fastest at 360/week | At an example 200/week | Approximate gift budget |
|---|---:|---:|---:|---|
| Coffee or treat | 120 | within week 1 | within week 1 | $5–$10 |
| Thriller/romance book | 250 | 1 week | 2 weeks | $15–$25 |
| Mini Sephora treat | 380 | 2 weeks | 2 weeks | $20–$30 |
| $20 fun money | 400 | 2 weeks | 2 weeks | $20 |
| Takeout night | 560 | 2 weeks | 3 weeks | $30–$50 |
| Movie date | 720 | 2 weeks | 4 weeks | $35–$70 |
| Beauty shopping | 1,150 | 4 weeks | 6 weeks | $75–$100 |
| Spa/massage | 1,900 | 6 weeks | 10 weeks | $120–$200 |
| Diamond earrings (agreed budget) | 5,200 | **15 weeks** | **26 weeks** | roughly $300–$900+ |

The timelines assume all earned points go to that prize and no earlier redemptions. Costs are illustrative and will vary with merchant and item.

## Premium styling

This release changes actual React Native styles and components, not just a mockup:
- system typography, neutral cream, muted sage, blush and white;
- tighter spacing, rounded cards, subdued elevation and a more polished navigation bar;
- a Pea Bank hero with individual shaded pea tokens collecting in a translucent jar, clear progress indicators and milestone tiles;
- premium micro-icons, simplified information hierarchy and the selected minimalist three-peas-in-a-pod branding.

## Daily Bhagavad Gita reflection

The five offline reflections remain optional, with original verse references and links. Reflections are labeled as original commentary rather than translated scripture. They do not update from the internet daily.

## Versioning & privacy

Uses the same `pea.planner.v1` storage key, so balances and plans from valid previous installs should carry forward when the new APK is installed over an app with the same package/signing certificate. Different signing keys may require a reinstall, which can wipe local data. No confidential BU student information or medication adherence is recorded for Pea Bank.
