/** Pea Rewards: optional, local-only, no automatic tracking of relationships, intimacy or medication. */
export type RewardActivityId='dishes'|'sweep'|'toys'|'schoolPrep'|'dinner'|'lunchKids'|'lunchPartner'|'thoughtfulText'|'familyPlan'|'rest';
export type RewardPrizeId='coffee'|'book'|'sephoraSmall'|'funMoney'|'takeout'|'movie'|'sephoraTrip'|'spa'|'earrings';
export type RewardEntry={id:string;kind:'earn'|'redeem';title:string;points:number;date:string;activityId?:RewardActivityId;prizeId?:RewardPrizeId};
export type RewardBank={enabled:boolean;balance:number;lifetimeEarned:number;entries:RewardEntry[];};
export type Activity={id:RewardActivityId;label:string;detail:string;points:number;icon:string;};
export type Prize={id:RewardPrizeId;label:string;points:number;estimatedCost:string;icon:string;};
// Rewards have deliberately limited earning potential; paid gifts require real-world agreement and funding.
export const WEEKLY_POINTS_CAP=360;
export const PEA_TOKEN_VALUE=20;
export const ACTIVITIES:Activity[]=[
 {id:'thoughtfulText',label:'A sweet little text',detail:'A thoughtful message during the day',points:15,icon:'chatbubble-ellipses-outline'},
 {id:'lunchPartner',label:'Made my partner lunch',detail:'A thoughtful surprise',points:40,icon:'heart-outline'},
 {id:'lunchKids',label:'Packed school lunches',detail:'One preparation session',points:28,icon:'bag-handle-outline'},
 {id:'dinner',label:'Dinner handled',detail:'Meal prep or cooking',points:28,icon:'restaurant-outline'},
 {id:'dishes',label:'Kitchen reset',detail:'Washed dishes / cleared the kitchen',points:22,icon:'sparkles-outline'},
 {id:'sweep',label:'Swept the floors',detail:'Made home feel fresh',points:18,icon:'home-outline'},
 {id:'toys',label:'Toys picked up',detail:'Tidied the play area',points:18,icon:'cube-outline'},
 {id:'schoolPrep',label:'Tomorrow is ready',detail:'Backpacks, clothes and supplies',points:25,icon:'calendar-outline'},
 {id:'familyPlan',label:'Family plan handled',detail:'An appointment, pickup or detail',points:25,icon:'people-outline'},
 {id:'rest',label:'Made time for herself',detail:'Rest or something she enjoys counts, too',points:25,icon:'flower-outline'},
];
export const PRIZES:Prize[]=[
 {id:'coffee',label:'Coffee or little treat',points:120,estimatedCost:'~$5–$10',icon:'cafe-outline'},
 {id:'book',label:'A new thriller or romance',points:250,estimatedCost:'~$15–$25',icon:'book-outline'},
 {id:'sephoraSmall',label:'Mini Sephora treat',points:380,estimatedCost:'~$20–$30',icon:'sparkles-outline'},
 {id:'funMoney',label:'$20 fun money',points:400,estimatedCost:'$20 gift budget',icon:'gift-outline'},
 {id:'takeout',label:'Takeout night (no cooking)',points:560,estimatedCost:'~$30–$50',icon:'pizza-outline'},
 {id:'movie',label:'Movie date night',points:720,estimatedCost:'~$35–$70',icon:'film-outline'},
 {id:'sephoraTrip',label:'Beauty shopping budget',points:1150,estimatedCost:'~$75–$100',icon:'bag-handle-outline'},
 {id:'spa',label:'Massage or spa day',points:1900,estimatedCost:'~$120–$200',icon:'rose-outline'},
 {id:'earrings',label:'Diamond earrings',points:5200,estimatedCost:'~$300–$900+ (budget together)',icon:'diamond-outline'},
];
export const emptyBank=():RewardBank=>({enabled:false,balance:0,lifetimeEarned:0,entries:[]});
export function mondayKey(dateStr:string):string{
 const d=new Date(dateStr+'T12:00:00');if(Number.isNaN(d.getTime()))return dateStr;
 const offset=(d.getDay()+6)%7; d.setDate(d.getDate()-offset);
 return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
export function pointsThisWeek(bank:RewardBank,date:string):number {const week=mondayKey(date);return bank.entries.filter(e=>e.kind==='earn'&&mondayKey(e.date)===week).reduce((s,e)=>s+e.points,0);}
export function canClaim(bank:RewardBank,id:RewardActivityId,date:string):{ok:boolean;reason?:string;award:number}{
 const activity=ACTIVITIES.find(a=>a.id===id);
 if(!activity)return {ok:false,reason:'Unknown activity',award:0};
 if(!bank.enabled)return {ok:false,reason:'Turn on rewards first',award:0};
 if(bank.entries.some(e=>e.kind==='earn'&&e.activityId===id&&e.date===date))return {ok:false,reason:'This activity was already added today',award:0};
 const remaining=WEEKLY_POINTS_CAP-pointsThisWeek(bank,date);
 if(remaining<=0)return {ok:false,reason:'The weekly pea bank is full. Enjoy your week!',award:0};
 return {ok:true,award:Math.min(remaining,activity.points)};
}
export function claimActivity(bank:RewardBank,id:RewardActivityId,date:string,entryId:string):RewardBank{
 const allowed=canClaim(bank,id,date);if(!allowed.ok)return bank;
 const activity=ACTIVITIES.find(a=>a.id===id)!;
 return {...bank,balance:bank.balance+allowed.award,lifetimeEarned:bank.lifetimeEarned+allowed.award,entries:[{id:entryId,kind:'earn',title:activity.label,points:allowed.award,date,activityId:id},...bank.entries].slice(0,500)};
}
export function redeemPrize(bank:RewardBank,id:RewardPrizeId,date:string,entryId:string):RewardBank{
 const prize=PRIZES.find(p=>p.id===id);
 if(!bank.enabled||!prize||bank.balance<prize.points)return bank;
 return {...bank,balance:bank.balance-prize.points,entries:[{id:entryId,kind:'redeem',title:prize.label,points:-prize.points,date,prizeId:id},...bank.entries].slice(0,500)};
}
export function projectedWeeks(points:number,weekly:number=WEEKLY_POINTS_CAP):number{return Math.ceil(points/Math.max(1,weekly));}
export function peasVisible(balance:number,max:number=35){const total=Math.floor(Math.max(0,balance)/PEA_TOKEN_VALUE);return {shown:Math.min(max,total),banked:total,extra:Math.max(0,total-max),towardNext:Math.max(0,balance)%PEA_TOKEN_VALUE};}

// A realistic illustrative pace: 200 points/week, alongside a theoretical cap of 360.
export const TYPICAL_WEEKLY_POINTS = 200;
export function projectedTimeframe(points:number):{fastWeeks:number;steadyWeeks:number}{
 return {fastWeeks:projectedWeeks(points,WEEKLY_POINTS_CAP),steadyWeeks:projectedWeeks(points,TYPICAL_WEEKLY_POINTS)};
}
