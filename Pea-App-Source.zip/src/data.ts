import type {RewardBank} from './rewards';
export type Section = 'home' | 'work';
export type Assignee = 'Pankhuri' | 'Partner';
export type Task = {id: string; title: string; section: Section; date: string; assignee: Assignee; done: boolean};
export type FamilyEvent = {id:string; title:string; date:string; time:string; category:'School'|'Family'|'Appointment'};
export type TreatCategory = 'thriller' | 'romance' | 'books' | 'movie' | 'beauty' | 'tiktok';
export type TreatStatus = 'saved' | 'started' | 'done';
export type Treat = {id:string; category:TreatCategory; title:string; note:string; url?:string; status:TreatStatus; createdAt:string};
export const treatCategories: {id:TreatCategory;name:string;emoji:string;description:string}[] = [
  {id:'thriller',name:'Thrillers',emoji:'🔍',description:'The next can’t-put-it-down book'},
  {id:'books',name:'Bookshelf',emoji:'📚',description:'Reading ideas from the bestseller charts'},
  {id:'romance',name:'Spicy reads',emoji:'💗',description:'Romance, spice & happy endings'},
  {id:'movie',name:'Movie nights',emoji:'🎬',description:'Everything you want to watch'},
  {id:'beauty',name:'Beauty shelf',emoji:'💄',description:'Makeup favorites & Sephora wishlist'},
  {id:'tiktok',name:'TikTok finds',emoji:'✨',description:'Videos and little ideas worth saving'},
];
export function treatStatusLabel(category:TreatCategory,status:TreatStatus):string {
  const words = category==='movie'?['Watchlist','Watching','Watched']
    : category==='beauty'?['Wishlist','Trying','Tried']
    : category==='tiktok'?['Saved','Trying','Tried']
    : ['Want to read','Reading','Finished'];
  return words[['saved','started','done'].indexOf(status)];
}
export function nextTreatStatus(status:TreatStatus):TreatStatus {
  return status==='saved'?'started':status==='started'?'done':'saved';
}
export function safePersonalLink(input:string):boolean {
  const text=input.trim();
  if(!text)return true;
  try {const u=new URL(text);return u.protocol==='https:' && Boolean(u.hostname) && !/\s/.test(text);}
  catch{return false;}
}
export type MealType = 'lunch' | 'dinner';
export type Meal = {id:string; title:string; kind:MealType; minutes:number; description:string; emoji:string; ingredients:string[]};
export type Reminder = {enabled:boolean; label:string; hour:number; minute:number; revealOnToday:boolean; doneDates:string[]; notificationId:string | null};
export type AppState = {
  tasks:Task[];
  groceries:{id:string;title:string;done:boolean}[];
  events:FamilyEvent[];
  preparedDates:string[];
  mealChoices:Record<string,{lunch?:string;dinner?:string}>;
  reminder:Reminder;
  introComplete:boolean;
  treats:Treat[];
  rewardBank:RewardBank;
  wisdomEnabled:boolean;
};
export const meals: Meal[] = [
  {id:'l1',kind:'lunch',title:'Rainbow lunchbox',minutes:12,description:'Wraps, berries and crunchy veggies',emoji:'🥪',ingredients:['Tortillas','Cheese','Berries','Carrots']},
  {id:'l2',kind:'lunch',title:'Mini pasta picnic',minutes:15,description:'Pasta, cucumber and strawberries',emoji:'🍓',ingredients:['Pasta','Cucumber','Strawberries']},
  {id:'l3',kind:'lunch',title:'Cheese & cracker box',minutes:8,description:'Simple, colorful and easy to pack',emoji:'🧀',ingredients:['Cheese','Crackers','Apple','Cucumbers']},
  {id:'l4',kind:'lunch',title:'Hummus & pita',minutes:10,description:'Pita wedges, hummus and fruit',emoji:'🥙',ingredients:['Pita','Hummus','Grapes','Carrots']},
  {id:'l5',kind:'lunch',title:'Leftover rice bowls',minutes:10,description:'Use last night’s rice and vegetables',emoji:'🍚',ingredients:['Rice','Vegetables','Chicken or tofu']},
  {id:'d1',kind:'dinner',title:'Creamy pesto pasta',minutes:20,description:'Comforting, simple and family-friendly',emoji:'🍝',ingredients:['Pasta','Pesto','Cream','Cherry tomatoes']},
  {id:'d2',kind:'dinner',title:'Sheet-pan chicken',minutes:30,description:'One pan means fewer dishes',emoji:'🍗',ingredients:['Chicken','Potatoes','Broccoli','Olive oil']},
  {id:'d3',kind:'dinner',title:'Taco night',minutes:20,description:'Easy to customize for everyone',emoji:'🌮',ingredients:['Tortillas','Beans','Cheese','Lettuce','Tomatoes']},
  {id:'d4',kind:'dinner',title:'Cozy veggie fried rice',minutes:18,description:'Great for leftover rice',emoji:'🍚',ingredients:['Rice','Eggs','Mixed vegetables','Soy sauce']},
  {id:'d5',kind:'dinner',title:'Butter chicken shortcut',minutes:25,description:'Serve with rice and quick veggies',emoji:'🍛',ingredients:['Chicken or paneer','Butter chicken sauce','Rice','Peas']},
  {id:'d6',kind:'dinner',title:'Baked salmon bowls',minutes:25,description:'Salmon, rice and crunchy cucumber',emoji:'🍣',ingredients:['Salmon','Rice','Cucumber','Yogurt']},
];
export const addDays=(base:Date,n:number) => {const d=new Date(base); d.setDate(d.getDate()+n);return d;};
export function dayKey(date:Date) {return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;}
export const initialState = ():AppState => {
  const today=dayKey(new Date());
  return {
    tasks:[
      {id:'seed-1',title:'Pack school lunches',section:'home',date:today,assignee:'Partner',done:false},
      {id:'seed-2',title:'Do the dishes',section:'home',date:today,assignee:'Partner',done:false},
      {id:'seed-3',title:'Choose dinner',section:'home',date:today,assignee:'Pankhuri',done:false},
      {id:'seed-4',title:'Set out backpacks & clothes',section:'home',date:today,assignee:'Partner',done:false},
      {id:'seed-5',title:'Review new-admit checklist',section:'work',date:today,assignee:'Pankhuri',done:false},
    ],
    groceries:[{id:'g1',title:'Milk',done:false},{id:'g2',title:'Fruit for lunches',done:false}],
    events:[],
    preparedDates:[today],
    mealChoices:{[today]:{lunch:'l1',dinner:'d1'}},
    reminder:{enabled:false,label:'Personal check-in',hour:20,minute:0,revealOnToday:false,doneDates:[],notificationId:null},
    introComplete:false,
    treats:[],
    rewardBank:{enabled:false,balance:0,lifetimeEarned:0,entries:[]},
    wisdomEnabled:true,
  };
};
export const workTemplates=[
  {title:'Missing documents',subtitle:'Friendly follow-up',body:'Subject: Next steps for your immigration documents\n\nHello,\n\nThank you for submitting your information. Before we can proceed, please review the items still required in your university portal. For your privacy, please use the approved university submission process rather than sending sensitive documents by email.\n\nIf you have questions, please reply and our team can guide you.\n\nBest,\nInternational Admissions Team'},
  {title:'Initial I-20 process',subtitle:'Student-facing overview',body:'Subject: Your next immigration-document steps\n\nHello,\n\nCongratulations on your admission! Please follow the instructions in your official university admissions and international student portals to submit required documentation. After your materials are reviewed, the appropriate university team will advise you about next steps.\n\nPlease refer to official university communications for case-specific instructions.\n\nBest,\nInternational Admissions Team'},
  {title:'Case review checklist',subtitle:'Internal reference (no student data)',body:'Newly admitted student checklist\n\n□ Confirm admission workflow stage in approved system\n□ Check document checklist in OnBase / Terra Dotta as authorized\n□ Verify required materials according to current BU guidance\n□ Check Campus Solutions status as authorized\n□ Review appropriate SEVIS-related steps with approved staff procedures\n□ Send approved follow-up template through Outlook\n□ Record actions in BU-approved systems\n\nDo not enter identifiable student records into Pea.'},
];
export const officialResources=[
 {title:'Travel & visa updates',agency:'U.S. Department of State',url:'https://travel.state.gov/content/travel/en/News/visas-news.html'},
 {title:'Student & Exchange Visitor Program',agency:'Study in the States · DHS',url:'https://studyinthestates.dhs.gov/'},
 {title:'Regulations & proposed rules',agency:'Federal Register',url:'https://www.federalregister.gov/'},
 {title:'SEVIS official resources',agency:'ICE · SEVP',url:'https://www.ice.gov/sevis'},
];
