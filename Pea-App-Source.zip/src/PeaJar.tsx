import React, {useEffect,useRef,useState} from 'react';
import {AccessibilityInfo,Animated,Easing,StyleSheet,Text,View} from 'react-native';
import {colors as C} from './theme';
import {peasVisible} from './rewards';

type Props={points:number;dropSignal:number};
const size=28;const cols=6;
function Pea({tiny=false}:{tiny?:boolean}){
 return <View style={[styles.pea,tiny&&{width:22,height:22,borderRadius:11}]}>
   <View style={styles.glint}/><View style={styles.peaShade}/>
 </View>;
}
/** Individual token positions are stable, while the just-awarded token visibly drops in. */
export function PeaJar({points,dropSignal}:Props){
 const count=peasVisible(points,30);
 const falling=useRef(new Animated.Value(-180)).current;
 const [animating,setAnimating]=useState(false);
 const [reduceMotion,setReduceMotion]=useState(false);
 useEffect(()=>{let active=true;AccessibilityInfo.isReduceMotionEnabled().then(value=>{if(active)setReduceMotion(value)}).catch(()=>{});return ()=>{active=false;}},[]);
 useEffect(()=>{
   if(dropSignal===0||reduceMotion)return;
   falling.stopAnimation();falling.setValue(-160);setAnimating(true);
   const anim=Animated.sequence([
     Animated.timing(falling,{toValue:123,duration:680,easing:Easing.in(Easing.quad),useNativeDriver:true}),
     Animated.spring(falling,{toValue:110,speed:18,bounciness:12,useNativeDriver:true}),
   ]);
   anim.start(({finished})=>{if(finished)setAnimating(false);});
   return ()=>{anim.stop();};
 },[dropSignal,reduceMotion,falling]);
 return <View style={styles.stage} accessibilityLabel={`Glass jar with ${count.banked} pea tokens, ${points} points total`}>
   <View style={styles.floatLeafLeft}/><View style={styles.floatLeafRight}/>
   <View style={styles.jar}>
     <View style={styles.glassSide}/>
     <View style={styles.gloss}/>
     {Array.from({length:count.shown},(_,i)=>{
       const row=Math.floor(i/cols),column=i%cols;
       const x=13+column*33+(row%2?4:0);
       const y=11+row*28;
       return <View key={i} style={{position:'absolute',left:x,bottom:y,zIndex:1}}><Pea/></View>;
     })}
     {count.shown===0?<Text style={styles.empty}>Your first pea lands here ♡</Text>:null}
   </View>
   <View style={styles.rimShadow}/><View style={styles.rim}>
     <View style={styles.rimInside}/>
   </View>
   {animating?<Animated.View pointerEvents="none" style={[styles.falling,{transform:[{translateY:falling},{rotate:'-14deg'}]}]}><Pea/></Animated.View>:null}
   <View style={styles.caption}><Text style={styles.captionStrong}>{count.banked.toLocaleString()} collected peas</Text><Text style={styles.captionSub}>1 pea = 20 points{count.extra?` · +${count.extra} safely saved`:''}</Text></View>
 </View>;
}
const styles=StyleSheet.create({
 stage:{height:330,alignItems:'center',justifyContent:'flex-start',paddingTop:38,overflow:'visible'},
 jar:{width:238,height:210,backgroundColor:'rgba(240,249,242,0.52)',borderColor:'#A8C3B1',borderWidth:2.4,borderTopWidth:0,borderTopLeftRadius:28,borderTopRightRadius:28,borderBottomLeftRadius:38,borderBottomRightRadius:38,overflow:'hidden',shadowColor:C.green,shadowOpacity:0.13,shadowRadius:14,shadowOffset:{width:0,height:8},elevation:3},
 glassSide:{position:'absolute',top:6,bottom:6,left:6,right:6,borderWidth:1.5,borderColor:'rgba(255,255,255,.86)',borderRadius:30},
 gloss:{position:'absolute',left:13,top:35,width:13,height:104,borderRadius:12,backgroundColor:'rgba(255,255,255,.86)',zIndex:2},
 rimShadow:{position:'absolute',top:32,width:211,height:17,borderRadius:50,backgroundColor:'#C8D7C9'},
 rim:{position:'absolute',top:23,width:220,height:21,borderWidth:3,borderColor:'#97B39D',borderRadius:55,backgroundColor:'rgba(246,250,247,.91)',justifyContent:'center',alignItems:'center'},
 rimInside:{width:184,height:8,borderRadius:20,backgroundColor:'#DCEBDD'},
 pea:{width:size,height:size,borderRadius:20,backgroundColor:'#96B995',borderWidth:1,borderColor:'#6F9A74',shadowColor:'#4F7755',shadowOpacity:.2,shadowRadius:2,shadowOffset:{width:0,height:2},elevation:1,overflow:'hidden'},
 glint:{width:10,height:6,borderRadius:12,backgroundColor:'#E2F0D9',position:'absolute',left:6,top:5,transform:[{rotate:'-30deg'}]},
 peaShade:{height:8,width:27,borderRadius:20,backgroundColor:'rgba(68,116,77,.15)',position:'absolute',bottom:-3},
 falling:{position:'absolute',zIndex:5,top:18,left:'49%',marginLeft:-14},
 empty:{fontSize:13,color:C.muted,position:'absolute',top:93,textAlign:'center',alignSelf:'center'},
 caption:{marginTop:12,alignItems:'center',gap:4},captionStrong:{fontSize:15,fontWeight:'700',color:C.text},captionSub:{fontSize:11,color:C.muted},
 floatLeafLeft:{position:'absolute',left:'4%',top:108,height:41,width:17,borderTopLeftRadius:23,borderBottomRightRadius:20,backgroundColor:'#DDEBD8',transform:[{rotate:'-27deg'}]},
 floatLeafRight:{position:'absolute',right:'6%',top:142,height:32,width:15,borderTopRightRadius:20,borderBottomLeftRadius:18,backgroundColor:'#E3EFE0',transform:[{rotate:'26deg'}]},
});
