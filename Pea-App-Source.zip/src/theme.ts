export const colors = {
  bg: '#FAFAF7',
  cream: '#FFFDFC',
  text: '#263A30',
  muted: '#78837B',
  green: '#627F68',
  greenSoft: '#ECF2EC',
  greenMid: '#DCE9DE',
  pink: '#D88FA4',
  pinkSoft: '#FFF0F2',
  pinkMid: '#F4D7DE',
  line: '#E9EDE9',
  white: '#FFFFFF',
  danger: '#AF5361',
};
export const radii = { card: 22, pill: 99, small: 14 };
export const shadow = {
  shadowColor: '#31483A', shadowOffset: {width: 0, height: 5},
  shadowOpacity: 0.055, shadowRadius: 17, elevation: 2,
} as const;
