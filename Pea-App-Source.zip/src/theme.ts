export const colors = {
  bg: '#FCFAF6',
  cream: '#FFFDF9',
  text: '#254332',
  muted: '#748176',
  green: '#52785D',
  greenSoft: '#EDF3E9',
  greenMid: '#DDEADD',
  pink: '#E996A9',
  pinkSoft: '#FCECEF',
  pinkMid: '#F5D4DC',
  line: '#EAEAE4',
  white: '#FFFFFF',
  danger: '#B45465',
};
export const radii = { card: 23, pill: 99, small: 15 };
export const shadow = {
  shadowColor: '#62775E', shadowOffset: {width: 0, height: 5},
  shadowOpacity: 0.05, shadowRadius: 14, elevation: 1,
} as const;
