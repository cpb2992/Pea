import React,{useEffect,useRef} from 'react';
import {AccessibilityInfo,Animated,Easing,Image,StyleSheet,Text,View} from 'react-native';
import {colors as C} from './theme';
const POD=require('../assets/pea-pod-mark.png');
const WORDMARK=require('../assets/pea-wordmark.png');
export function WelcomeSplash(){
 const wiggles=useRef([new Animated.Value(0),new Animated.Value(0),new Animated.Value(0)]).current;
 useEffect(()=>{
   let active=true;const loops:Animated.CompositeAnimation[]=[];
   AccessibilityInfo.isReduceMotionEnabled().then(reduced=>{
     if(!active||reduced)return;
     wiggles.forEach((v,i)=>{
       const loop=Animated.loop(Animated.sequence([
         Animated.delay(i*130),
         Animated.timing(v,{toValue:-10,duration:220,easing:Easing.out(Easing.quad),useNativeDriver:true}),
         Animated.spring(v,{toValue:0,friction:3,tension:70,useNativeDriver:true}),
         Animated.delay(340-i*65),
       ]));loops.push(loop);loop.start();
     });
   }).catch(()=>{});
   return ()=>{active=false;loops.forEach(a=>a.stop());};
 },[wiggles]);
 return <View style={styles.back} accessibilityLabel="Opening Pea, three playful peas gently wiggling">
   <View style={styles.logo}><Image source={POD} resizeMode="contain" style={styles.pod}/><Image source={WORDMARK} resizeMode="contain" style={styles.wordmark}/></View>
   <View style={styles.row}>{wiggles.map((v,i)=><Animated.View key={i} style={[styles.dot,{transform:[{translateY:v},{rotate:v.interpolate({inputRange:[-10,0],outputRange:['-13deg','0deg']})}]}]}><View style={styles.shine}/></Animated.View>)}</View>
   <Text style={styles.caption}>a little help with a lot of life</Text>
 </View>;
}
const styles=StyleSheet.create({
 back:{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:C.bg,gap:19},
 logo:{alignItems:'center',gap:0},pod:{width:230,height:135},wordmark:{width:195,height:78},
 row:{flexDirection:'row',gap:13,marginTop:-3,minHeight:34,alignItems:'center'},dot:{height:25,width:25,borderRadius:14,backgroundColor:'#8DAE91',borderWidth:1,borderColor:'#7A9B80',shadowColor:'#718E73',shadowRadius:3,shadowOpacity:.14},shine:{height:7,width:9,borderRadius:8,backgroundColor:'#D5E8D2',position:'absolute',top:5,left:5},
 caption:{marginTop:8,fontSize:12,color:C.muted,letterSpacing:1.1},
});
