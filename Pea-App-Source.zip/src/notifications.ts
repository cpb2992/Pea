import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// Notifications never contain the name or purpose of the personal reminder.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function enablePrivateDailyNotification(hour:number, minute:number, priorId:string|null) {
  const permission = await Notifications.getPermissionsAsync();
  let granted = permission.granted;
  if (!granted && permission.canAskAgain) {
    const result = await Notifications.requestPermissionsAsync();
    granted = result.granted;
  }
  if (!granted) throw new Error('Notifications are disabled. You can allow them in iPhone Settings.');
  if (priorId) await Notifications.cancelScheduledNotificationAsync(priorId).catch(()=>{});
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('pea-personal', {
      name:'Pea personal reminders',importance:Notifications.AndroidImportance.DEFAULT,
    });
  }
  return Notifications.scheduleNotificationAsync({
    content:{title:'A little note from Pea 🌱',body:'Your private daily check-in is ready.',sound:false},
    trigger:{type:Notifications.SchedulableTriggerInputTypes.DAILY,hour,minute, ...(Platform.OS==='android'?{channelId:'pea-personal'}:{})},
  });
}
export async function clearPrivateNotification(id:string|null){if(id)await Notifications.cancelScheduledNotificationAsync(id).catch(()=>{});}
