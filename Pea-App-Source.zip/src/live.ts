/**
 * Pea public-data feeds. None of these requests include user tasks, health details,
 * BU records, email addresses, or student information.
 *
 * Live results must be positively confirmed. An offline snapshot is ALWAYS labelled
 * as a snapshot, never passed off as a current regulatory determination.
 */
export const URLS = {
  dosRestrictions: 'https://travel.state.gov/en/newsroom/visas/2026/suspension-of-visa-issuance-to-foreign-nationals-to-protect-the-security-of-the-united-states.html',
  dosVisaNews: 'https://travel.state.gov/content/travel/en/News/visas-news.html',
  federalRegister: 'https://www.federalregister.gov/',
  durationFinal: 'https://www.federalregister.gov/documents/2026/07/17/2026-14439/establishing-a-fixed-time-period-of-admission-and-an-extension-of-stay-procedure-for-nonimmigrant',
  durationLitigation: 'https://www.nafsa.org/legal-defense-DS',
  durationStatus: 'https://iss.washington.edu/duration-of-status/',
  simklMovieFeed: 'https://data.simkl.in/discover/trending/movies/week_100.json',
  simklMovies: 'https://simkl.com/movies/best-movies/most-watched/',
  appleBooks: 'https://rss.applemarketingtools.com/api/v2/us/books/top-paid/25/books.json',
  appleBooksCharts: 'https://books.apple.com/us/charts',
  thrillerBooks: 'https://openlibrary.org/search.json?q=subject%3Athrillers&sort=trending&fields=key%2Ctitle%2Cauthor_name%2Cfirst_publish_year%2Ccover_i&limit=12',
  romanceBooks: 'https://openlibrary.org/search.json?q=subject%3Aromance&sort=trending&fields=key%2Ctitle%2Cauthor_name%2Cfirst_publish_year%2Ccover_i&limit=12',
  sephora: 'https://www.sephora.com/beauty/best-selling-makeup',
  tiktok: 'https://www.tiktok.com/',
} as const;

export type FeedCategory = 'movie'|'bestsellers'|'thriller'|'romance';
export type LivePick = {id:string;title:string;subtitle:string;url:string;image?:string;source:string};
export type CountryCategory = 'full'|'student'|'immigrant';
export type CountryInfo = {name:string;category:CountryCategory};
export type Restrictions = {
  countries:CountryInfo[];
  sourceDate:string;
  sourceUrl:string;
  lastChecked?:string;
  liveVerified:boolean;
  note:string;
};
export type RuleNotice = {id:string;title:string;url:string;type:string;published:string};

const full2026=['Afghanistan','Burma','Burkina Faso','Chad','Republic of the Congo','Equatorial Guinea','Eritrea','Haiti','Iran','Laos','Libya','Mali','Niger','Sierra Leone','Somalia','South Sudan','Sudan','Syria','Yemen'];
const partial2026=['Angola','Antigua and Barbuda','Benin','Burundi','Cote D’Ivoire','Cuba','Dominica','Gabon','The Gambia','Malawi','Mauritania','Nigeria','Senegal','Tanzania','Togo','Tonga','Venezuela','Zambia','Zimbabwe'];
export const restrictionSnapshot:Restrictions = {
  countries:[...full2026.map(name=>({name,category:'full' as const})),...partial2026.map(name=>({name,category:'student' as const})),{name:'Turkmenistan',category:'immigrant'}],
  sourceDate:'February 2, 2026', sourceUrl:URLS.dosRestrictions,
  liveVerified:false,
  note:'Published Department of State snapshot, not a live clearance. Restrictions, exceptions and court orders may change. Verify at the official source.',
};

function asText(value:any):string {return typeof value==='string'?value:'';}
function validHttpUrl(value:unknown):string {
  if(typeof value!=='string')return '';
  try {const u=new URL(value);return u.protocol==='https:'?u.toString():'';}catch{return '';}
}
function asObjectArray(raw:any):any[] {return Array.isArray(raw)?raw:Array.isArray(raw?.items)?raw.items:[];}

export function parseMovieFeed(raw:any):LivePick[] {
  const rows=asObjectArray(raw);
  return rows.slice(0,25).map((item:any,i:number)=>{
    const title=asText(item?.title||item?.movie?.title);
    const year=item?.year||item?.release_date?.slice?.(0,4)||item?.movie?.year;
    const simklId=item?.ids?.simkl||item?.id;
    const direct=validHttpUrl(item?.url||item?.link);
    const url=direct|| (simklId?`https://simkl.com/movies/${encodeURIComponent(String(simklId))}/`:URLS.simklMovies);
    // Remote artwork is optional; never manufacture a poster URL.
    const image=validHttpUrl(item?.poster||item?.image||item?.poster_url);
    return {id:`simkl-${simklId||i}`,title,subtitle:year?String(year):'Popular this week',url,image:image||undefined,source:'Simkl'};
  }).filter(x=>x.title).slice(0,10);
}
export function parseAppleBooks(raw:any):LivePick[] {
  const rows=raw?.feed?.results;
  if(!Array.isArray(rows))return [];
  return rows.slice(0,12).map((row:any,i:number)=>({
    id:`apple-${row?.id||i}`,title:asText(row?.name),subtitle:asText(row?.artistName),
    url:validHttpUrl(row?.url)||URLS.appleBooksCharts,
    image:validHttpUrl(row?.artworkUrl100||row?.artworkUrl60)||undefined,
    source:'Apple Books',
  })).filter((x:RuleNotice)=>Boolean(x.title));
}
export function parseOpenLibrary(raw:any):LivePick[] {
  const rows=raw?.docs;
  if(!Array.isArray(rows))return [];
  return rows.slice(0,15).map((row:any,i:number)=>{
    const path=asText(row?.key);
    return {
      id:`open-${path||i}`,title:asText(row?.title),
      subtitle:Array.isArray(row?.author_name)?row.author_name.slice(0,2).join(', '):'',
      url:path.startsWith('/works/')?`https://openlibrary.org${path}`:'https://openlibrary.org/trending',
      image:Number.isInteger(row?.cover_i)&&row.cover_i>0?`https://covers.openlibrary.org/b/id/${row.cover_i}-M.jpg`:undefined,
      source:'Open Library',
    };
  }).filter(x=>x.title).slice(0,10);
}

export function stripHtml(html:string):string {
  return html.replace(/<!--[\s\S]*?-->/g,' ')
    .replace(/<(?:script|style|nav|footer)\b[^>]*>[\s\S]*?<\/(?:script|style|nav|footer)>/gi,' ')
    .replace(/<[^>]+>/g,' ')
    .replace(/&nbsp;|&#160;/gi,' ').replace(/&ndash;|&#8211;/gi,'–')
    .replace(/&mdash;|&#8212;/gi,'—').replace(/&#39;|&apos;/gi,"'")
    .replace(/&rsquo;|&#8217;/gi,'’').replace(/&amp;/gi,'&')
    .replace(/\s+/g,' ').trim();
}
function countriesFrom(text:string,start:RegExp,end:RegExp):string[] {
  const startMatch=start.exec(text);if(!startMatch)return [];
  const segment=text.slice(startMatch.index+startMatch[0].length);
  const endMatch=end.exec(segment);if(!endMatch)return [];
  const raw=segment.slice(0,endMatch.index).replace(/^[\s–—:,-]+/,'').replace(/[.\s]+$/,'');
  if(raw.length>950)return [];
  return raw.split(/,\s*/g).flatMap((piece,i,all)=>{
    // The last country in DOS lists is introduced by "and"; preserve country names such as "Antigua and Barbuda".
    const part=(i===all.length-1?piece.replace(/^and\s+/i,''):piece).trim();
    if(i===all.length-1&&/\s+and\s+/i.test(part)){
      // DOS normally uses an Oxford comma; support list ending without it.
      const m=part.match(/^(.+?)\s+and\s+([^,]+)$/i);
      if(m&&m[1]!=='Antigua')return [m[1].trim(),m[2].trim()];
    }
    return [part];
  }).filter(Boolean);
}
/** Fail closed: don't return a 'live verified' list unless BOTH entire groups match the publication structure. */
export function parseDosRestrictions(html:string,checkedAt:string):Restrictions|null {
  const text=stripHtml(html);
  if(!/Presidential Proclamation 10998/i.test(text))return null;
  const full=countriesFrom(text,/fully suspended visa issuance to nationals of 19 countries/i,/for all nonimmigrant and immigrant visa categories/i);
  const partial=countriesFrom(text,/partially suspended visa issuance to nationals of 19 countries/i,/for nonimmigrant B-1\/B-2 visitor visas and F, M, J student/i);
  if(full.length!==19||partial.length!==19||new Set([...full,...partial]).size!==38)return null;
  if(!/Turkmenistan for all immigrant visas/i.test(text))return null;
  const sourceDate=text.match(/(?:Last Updated|Published):?\s*(February\s+2,\s+2026|[A-Z][a-z]+\s+\d{1,2},\s+20\d{2})/i)?.[1]||'See source publication';
  return {
    countries:[...full.map(name=>({name,category:'full' as const})),...partial.map(name=>({name,category:'student' as const})),{name:'Turkmenistan',category:'immigrant'}],
    sourceDate,sourceUrl:URLS.dosRestrictions,liveVerified:true,lastChecked:checkedAt,
    note:'Fetched directly from a Department of State page. Always verify the full guidance and exceptions before acting; a successful fetch cannot guarantee that no other policy has changed.',
  };
}

export function parseFederalNotices(raw:any):RuleNotice[] {
  if(!Array.isArray(raw?.results))return [];
  return raw.results.slice(0,10).map((row:any,i:number)=>({
    id:asText(row?.document_number)||`federal-${i}`,
    title:asText(row?.title),url:validHttpUrl(row?.html_url)||URLS.federalRegister,
    type:asText(row?.type)||'Federal Register document',published:asText(row?.publication_date),
  })).filter((x:RuleNotice)=>Boolean(x.title));
}
export const FR_SEARCH='https://www.federalregister.gov/api/v1/documents.json?conditions%5Bterm%5D=duration%20of%20status%20student&per_page=8&order=newest';

async function fetchWithTimeout(url:string,json:boolean,ms=12000):Promise<any> {
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),ms);
  try {
    const response=await fetch(url,{signal:controller.signal,headers:{'Accept':json?'application/json':'text/html','User-Agent':'PeaPersonal/1.3 (individual-use)'}});
    if(!response.ok)throw new Error(`Source returned ${response.status}`);
    return json?response.json():response.text();
  } finally {clearTimeout(timer);}
}
export async function getPicks(category:FeedCategory):Promise<LivePick[]> {
  const url=category==='movie'?URLS.simklMovieFeed:category==='bestsellers'?URLS.appleBooks:category==='thriller'?URLS.thrillerBooks:URLS.romanceBooks;
  const data=await fetchWithTimeout(url,true);
  const picks=category==='movie'?parseMovieFeed(data):category==='bestsellers'?parseAppleBooks(data):parseOpenLibrary(data);
  if(!picks.length)throw new Error('The source did not return any titles.');
  return picks;
}
export async function getRestrictions():Promise<Restrictions> {
  const html=await fetchWithTimeout(URLS.dosRestrictions,false,17000);
  const result=parseDosRestrictions(html,new Date().toISOString());
  if(!result)throw new Error('The government page changed format, so Pea could not safely verify the country list. Use the official source instead.');
  return result;
}
export async function getFederalNotices():Promise<RuleNotice[]> {
  const data=await fetchWithTimeout(FR_SEARCH,true);
  const notices=parseFederalNotices(data);
  if(!notices.length)throw new Error('No matching government notices were returned.');
  return notices;
}
