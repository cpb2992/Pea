/** Original, concise reflection paraphrases, NOT presented as scripture translations. */
export type Wisdom={ref:string;sanskrit:string;reflection:string;thought:string;url:string};
export const WISDOM:Wisdom[]=[
 {ref:'Bhagavad Gita 2.47',sanskrit:'कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।',reflection:'Focus on the care you put into your actions, not only on the outcome.',thought:'One loving effort at a time.',url:'https://heritage.iitk.ac.in/SBG/2.47'},
 {ref:'Bhagavad Gita 2.48',sanskrit:'समत्वं योग उच्यते।',reflection:'Meet progress and setbacks with the same steady spirit.',thought:'Balance is a kind of strength.',url:'https://heritage.iitk.ac.in/SBG/2.48'},
 {ref:'Bhagavad Gita 6.5',sanskrit:'उद्धरेदात्मनाऽऽत्मानं नात्मानमवसादयेत्।',reflection:'Offer yourself the support you would give a dear friend.',thought:'You deserve kindness, too.',url:'https://heritage.iitk.ac.in/SBG/6.5'},
 {ref:'Bhagavad Gita 6.26',sanskrit:'यतो यतो निश्चरति मनश्चञ्चलमस्थिरम्।',reflection:'When your thoughts wander, gently guide them back.',thought:'A fresh start is always available.',url:'https://heritage.iitk.ac.in/SBG/6.26'},
 {ref:'Bhagavad Gita 12.13',sanskrit:'अद्वेष्टा सर्वभूतानां मैत्रः करुण एव च।',reflection:'Practice friendliness and compassion toward every living being.',thought:'Let tenderness be part of your day.',url:'https://heritage.iitk.ac.in/SBG/12.13'},
];
export function dailyWisdom(date:string):Wisdom{
 const n=Number(date.replace(/-/g,''));return WISDOM[(Number.isFinite(n)?n:0)%WISDOM.length];
}
