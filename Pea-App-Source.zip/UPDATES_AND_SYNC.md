# Pea v1.6 — Builds, animated opening, rewards and OTA updates

## What's in this release
- **Splash:** The native splash uses the chosen Pea splash artwork through the expo-splash-screen config plugin. Once JS loads, the screen shows the chosen logo with three small peas gently bouncing for ~1.6 seconds. Reduced-motion preferences disable the wiggle.
- **Pea Bank:** Real local points determine the jar token count. An individual pea visibly falls into the glass jar on every successful award, with a little bounce. One token represents 20 points, with a total-label for all saved peas when the jar looks full.
- **Both can award:** Choose Chris or Pankhuri before adding an activity, or choose Add Peas → a 20/40/60 point surprise. The log records who made each award. The original 360-point weekly cap and one-surprise-per-person-per-day rule still apply.
- **Greetings:** Good morning/afternoon/evening; no literal `\n` text.
- **Data:** The existing AsyncStorage key `pea.planner.v1` is retained. Do not uninstall the old APK without a backup, because uninstall erases saved data.

## Important sharing limitation
Both people can mark awards **on the same device**. There is currently **no shared cloud database**, so two phones would not see the same balance. Adding authenticated, permission-controlled family sync is a separate step, and should happen before offering multi-device rewards as fully synchronized.

## Over-the-air preparation (not active by default)
The `expo-updates` dependency is included, EAS preview/production channels are defined, and a configuration script is included. OTA remains deliberately disabled until linked to your own Expo project. No project identifier or Expo credentials are bundled here.

1. Create/link Pea on expo.dev and note your project's UUID (for example, `eas project:init` / `eas project:info`).
2. Set a repository Actions secret named `EXPO_EAS_PROJECT_ID` containing that UUID, or locally run `node scripts/enable-ota.mjs YOUR-EXPO-PROJECT-UUID`.
3. Install the **updated GitHub build workflow** from `Pea-v1.6-Standalone-Android-build.yml` into `.github/workflows/build.yml` in your `cpb2992/Pea` repo. It reads the optional Actions secret and configures updates on build.
4. Produce and install a NEW signed APK with that configuration. Your existing APK cannot start receiving OTA updates just because app source changed.
5. From an authenticated Expo CLI, run `eas update --channel preview --message "Pea app improvements"` from a project with the same native runtime. The preview build picks up compatible JavaScript/assets on subsequent launches.

The account setup and update publishing require Expo authentication; the current project file alone does **not** deploy an update. Native dependencies, app icon or native splash changes still require a new signed build. Keep signing credentials stable if you want to upgrade an existing install without losing local data.

## Updating through GitHub from a Samsung
Replace `Pea-App-Source.zip` in your repo with the new matching source ZIP. The existing native build workflow will build an APK. Use the v1.6 workflow to enable OTA after linking Expo. After a successful run, get the APK from GitHub Actions → Artifacts.
