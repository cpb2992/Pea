/** Enable OTA only after linking Pea to a real Expo EAS project. Never invent a project ID. */
import fs from 'node:fs';
const id=(process.argv[2]||process.env.EXPO_EAS_PROJECT_ID||'').trim();
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
if(!uuid.test(id)){console.error('Missing or invalid Expo EAS project UUID. Set EXPO_EAS_PROJECT_ID after linking at expo.dev.');process.exit(1);}
const filename='app.json';const cfg=JSON.parse(fs.readFileSync(filename,'utf8'));
cfg.expo.runtimeVersion={policy:'appVersion'};
cfg.expo.extra={...(cfg.expo.extra||{}),eas:{projectId:id}};
cfg.expo.updates={enabled:true,url:`https://u.expo.dev/${id}`,checkAutomatically:'ON_LOAD',fallbackToCacheTimeout:0};
fs.writeFileSync(filename,JSON.stringify(cfg,null,2)+'\n');
console.log('Expo OTA configured for the linked EAS project; a fresh signed native build is required.');
