# pea. v1.6 — Premium Family Companion

Personal iOS and Android app project for Pankhuri, with a calm sage-and-blush interface.

## New in 1.6
- **Your Pea Bank** contains an illustrated glass jar, populated with actual earned pea tokens (one pea per 20 points). Peas fall into the jar and bounce when points are awarded; motion preferences are respected.
- **Both can add peas on this phone:** choose Chris or Pankhuri as the awarder, tap a completed activity, or give a 20, 40 or 60-point thoughtful surprise with an optional note. History records who gave it. All awards count toward the existing 360-point weekly cap.
- **Splash:** the chosen logo appears as the native loading artwork followed by a gentle on-screen three-pea wiggle. No external GIFs or cloud dependencies needed.
- **Greeting:** natural time-of-day greeting for Pankhuri; actual line breaks rather than the literal `\n` string.
- **OTA preparation:** Expo Update library and EAS preview/production channel configuration included. OTA is intentionally inactive until linked to your Expo EAS project and you install a new native build. See `UPDATES_AND_SYNC.md`.

All existing tasks, saved rewards, work references, personal reminders, and entertainment discovery screens are retained. No BU student data is fetched or saved.

## Build with the existing GitHub setup
Your GitHub repository's workflow expects a ZIP file called **Pea-App-Source.zip** at repository root. Upload this ZIP, replacing the previous one. GitHub will then build a new Android APK using the workflow already in your repo.

Use `Pea-v1.6-Standalone-Android-build.yml` as `.github/workflows/build.yml` when you want to enable the optional OTA configuration via the `EXPO_EAS_PROJECT_ID` repository secret.

If building on a computer: `npm install`, `npm test`, `npm run check` and for an Expo development server `npx expo start`. For Android standalone release through GitHub Actions, see the workflow file. iOS requires native signing through Apple.

## Important limitations
- Rewards and plans persist **locally**. They are not synchronized across two phones. Actor attribution is not a replacement for secure multi-device syncing.
- The GitHub-built APK and all animations **still need device testing**. Local automated tests verify logic and source structure, not the full native build.
- If uninstalling an old APK to resolve signing conflicts, local data may be lost. Prefer an install-over upgrade using the same signing key.
- OTA updates require a real Expo account/project and an authenticated publish. This archive alone cannot push live updates.

## Details
See `UPDATES_AND_SYNC.md`, `REWARDS_AND_WISDOM.md`, `LIVE_FEEDS.md` and `BRANDING_UPDATE.md`.
