# Pea visual refresh — v1.2

The selected three-peas-in-a-pod logo is now the source of truth.

- App launcher icon: the exact three-pea pod on a warm cream square (no tiny text)
- Adaptive Android icon: isolated pod art with safe transparent margins
- Inside Pea: pod art on Home and Pea Pod, actual wordmark in the top navigation and modals, subtle pod symbol in bottom navigation
- Sage, cream and blush tones sampled and adapted from the selected artwork
- Splash artwork: full pod-and-wordmark lockup
- Expo internal app name is `Pea`, which is safe for Gradle; the user-facing wordmark remains `pea.`

To update GitHub Android build: replace the repository's existing `Pea-App-Source.zip` with the new ZIP from this release, then commit. The existing workflow must assemble a **release** APK with JavaScript bundled; a debug APK will still require Metro.

Version code bumped to 3; icon updates can require uninstall/reinstall before the OS icon cache refreshes.
