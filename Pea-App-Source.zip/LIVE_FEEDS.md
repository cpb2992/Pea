# Pea v1.3 — Internet-powered Pea Picks and Work Watch

## What's new

### Pea Pod → Pea Picks ♡

- **Trending movies:** Simkl's publicly documented weekly movie-trending feed (requires source attribution; Pea shows it).
- **Book charts:** Apple Books top-paid U.S. books feed.
- **Thrillers / Romance:** Open Library's search API with `sort=trending`. Romance recommendations are not independently classified by spice level, and results may include less-explicit romances.
- **Beauty / TikTok:** opens Sephora's and TikTok's websites. **No TikTok or Sephora account integration** and no purported in-app real-time rankings for those services.
- Pull-to-sync is via a **Refresh** button. Save an item to the local My Happy Place list with an individual source link.
- Connectivity failure produces an error and source link, not made-up titles. No background syncing or scheduled push alerts.

### Work → Pea Work Watch

- **Visa restrictions:** app fetches the official U.S. Department of State PP 10998 article (February 2, 2026 publication) and extracts the **full 19 / F-M-J affected 19 / immigrant-only 1** country groups, then labels when the official page was actually fetched. If parsing fails or internet is unavailable, it shows an explicitly **unverified Feb. 2 snapshot**, not a live clearance.
- **Country search/filter:** search local public country names, with each category explained; F/M/J restrictions are distinct from restrictions that apply only to immigrant visas. Country-by-country exceptions can apply.
- **D/S status:** a contextual banner records the September 14, 2026 court injunction; snapshot reviewed October 25, 2026. **Pea does not automatically adjudicate ongoing litigation.** Buttons open NAFSA's litigation tracker and the July 17 Federal Register final rule; always re-check court orders and current BU procedure.
- **Federal Register notices:** a JSON API query for documents mentioning duration of status and students, with title, publication date, type, and links. Titles are not an operative-rule determination.
- **No private records:** This is a generic personal reference tool. Never use it to process identifiable BU student, SEVIS, passport, or immigration data without authorization.

## Network and privacy

All network requests are HTTPS GET requests for **public** pages/feeds. Pea does not send household tasks, medication reminders, favorite lists, names, BU credentials, student details, or message contents to these services. Like any direct internet request, the external services can see the device IP address and customary connection metadata. None of the feeds require an API key for the single-user use case described, though external services can change availability, quotas, acceptable uses, or response formats.

Do not use this personal app as a definitive immigration-law or visa-eligibility tool. **A "Fetched" timestamp means only that Pea retrieved and parsed the cited DOS page successfully**, not that every source, exception, court order, and local policy has been reviewed. The app intentionally displays errors if a government page's layout changes.

## Official/source links

- DOS PP 10998: https://travel.state.gov/en/newsroom/visas/2026/suspension-of-visa-issuance-to-foreign-nationals-to-protect-the-security-of-the-united-states.html
- Federal Register D/S final rule: https://www.federalregister.gov/documents/2026/07/17/2026-14439/establishing-a-fixed-time-period-of-admission-and-an-extension-of-stay-procedure-for-nonimmigrant
- NAFSA D/S court action and appeal: https://www.nafsa.org/legal-defense-DS
- Federal Register API: https://www.federalregister.gov/developers/documentation/api/v1
- Simkl Trending API: https://simkl.docs.apiary.io/reference/anime/genres (current docs at https://api.simkl.org)
- Apple Marketing Tools: https://performance-partners.apple.com/tools
- Open Library Search API: https://openlibrary.org/dev/docs/api/search

## Testing / release status

- Local pure-function tests have passed. External HTTPS calls **could not be tested live** here because this coding container has no internet access.
- A GitHub Actions Android release APK workflow is supplied, but it has **not** been run on this version. The project has **not** been tested on a physical Android or iOS device.
- GitHub `cpb2992/Pea` is private and not writable by the currently connected GitHub tool. Upload the updated source ZIP with the expected repository filename `Pea-App-Source.zip` to the repository's main branch. The new build workflow can replace `.github/workflows/build.yml`. The source ZIP should not be extracted before upload; the workflow unzips it.
- For Google Play a production-signed AAB is required; the test APK isn't a store release. For iOS, signing/TestFlight requires a configured Apple Developer account.
