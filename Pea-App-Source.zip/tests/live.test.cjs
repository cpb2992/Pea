const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const ts=require('typescript');
function loadTS(file){const js=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText; const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));mod._compile(js,file);return mod.exports;}
const m=loadTS(path.join(__dirname,'../src/live.ts'));

test('DOS published snapshot separates 19 full, 19 F/M/J and one immigrant-only country',()=>{
 const x=m.restrictionSnapshot;
 assert.equal(x.liveVerified,false);
 assert.equal(x.countries.length,39);
 assert.equal(x.countries.filter(c=>c.category==='full').length,19);
 assert.equal(x.countries.filter(c=>c.category==='student').length,19);
 assert.deepEqual(x.countries.filter(c=>c.category==='immigrant').map(c=>c.name),['Turkmenistan']);
});

test('parse DOS original publication and preserve country names containing and',()=>{
 const full=m.restrictionSnapshot.countries.filter(x=>x.category==='full').map(x=>x.name);
 const partial=m.restrictionSnapshot.countries.filter(x=>x.category==='student').map(x=>x.name);
 const html=`<html><h1>Presidential Proclamation 10998</h1><p>Published: February 2, 2026</p><p>Department of State fully suspended visa issuance to nationals of 19 countries – ${full.slice(0,-1).join(', ')}, and ${full.at(-1)} – for all nonimmigrant and immigrant visa categories with limited exceptions</p><p>Department of State partially suspended visa issuance to nationals of 19 countries – ${partial.slice(0,-1).join(', ')}, and ${partial.at(-1)} – for nonimmigrant B-1/B-2 visitor visas and F, M, J student and exchange visitor visas</p><p>partially suspended visa issuance to nationals of Turkmenistan for all immigrant visas</p></html>`;
 const r=m.parseDosRestrictions(html,'2026-10-25T13:00:00Z');
 assert.ok(r,'parses a well-structured official format');
 assert.equal(r.countries.length,39);
 assert.equal(r.liveVerified,true);
 assert.ok(r.countries.some(c=>c.name==='Antigua and Barbuda'));
 assert.ok(r.countries.some(c=>c.name==='Republic of the Congo'));
});

test('parser refuses a partial or unrelated page instead of inventing live verification',()=>{
 assert.equal(m.parseDosRestrictions('<html>Presidential Proclamation 10998</html>','date'),null);
 assert.equal(m.parseDosRestrictions('<html>Service temporarily unavailable</html>','date'),null);
});

test('movie, bestseller, thriller, and Federal Register parsers do not invent titles',()=>{
 assert.deepEqual(m.parseMovieFeed({}),[]);
 assert.deepEqual(m.parseAppleBooks({}),[]);
 assert.deepEqual(m.parseOpenLibrary({}),[]);
 assert.deepEqual(m.parseFederalNotices({}),[]);
 assert.equal(m.parseMovieFeed([{title:'A Test Movie',year:2026,ids:{simkl:123},poster:'javascript:evil()'}])[0].image,undefined);
 assert.equal(m.parseAppleBooks({feed:{results:[{name:'A Novel',artistName:'Author',id:'X',url:'https://books.apple.com/test'}]}})[0].title,'A Novel');
 assert.equal(m.parseOpenLibrary({docs:[{key:'/works/OL123W',title:'A Thriller',author_name:['Author']}]})[0].url,'https://openlibrary.org/works/OL123W');
 assert.equal(m.parseFederalNotices({results:[{title:'A regulation',type:'Rule',publication_date:'2026-10-25',html_url:'https://www.federalregister.gov/a'}]})[0].type,'Rule');
});

test('live feed addresses use HTTPS and US government source',()=>{
 for (const [name,url] of Object.entries(m.URLS))assert.equal(new URL(url).protocol,'https:',name);
 assert.match(m.URLS.dosRestrictions,/travel\.state\.gov/);
 assert.match(m.URLS.durationFinal,/federalregister\.gov/);
});
