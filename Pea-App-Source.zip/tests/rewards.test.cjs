const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const ts=require('typescript');
function loadTS(file){const js=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));mod._compile(js,file);return mod.exports;}
const r=loadTS(path.join(__dirname,'../src/rewards.ts'));
const w=loadTS(path.join(__dirname,'../src/wisdom.ts'));
test('points bank starts off and has no data',()=>{const b=r.emptyBank();assert.equal(b.enabled,false);assert.equal(b.balance,0);assert.deepEqual(b.entries,[]);});
test('claim is opt-in and only one activity per calendar day',()=>{
 let b=r.emptyBank();const date='2026-10-25';assert.equal(r.claimActivity(b,'lunchPartner',date,'a'),b);
 b={...b,enabled:true};b=r.claimActivity(b,'lunchPartner',date,'a');assert.equal(b.balance,40);
 assert.deepEqual(r.claimActivity(b,'lunchPartner',date,'b'),b);
 b=r.claimActivity(b,'lunchPartner','2026-10-26','b');assert.equal(b.balance,80);
});
test('weekly cap cannot be bypassed by many actions',()=>{
 let b={...r.emptyBank(),enabled:true};let n=0;
 for(let date=20;date<=26;date++)for(const a of r.ACTIVITIES){const dk=`2026-10-${date}`;b=r.claimActivity(b,a.id,dk,`e${n++}`);}
 const total=r.pointsThisWeek(b,'2026-10-25'); assert.ok(total<=r.WEEKLY_POINTS_CAP);assert.ok(b.balance<=r.WEEKLY_POINTS_CAP+r.WEEKLY_POINTS_CAP); // two weeks in this range
});
test('redemption costs points and cannot overdraft; luxury gifts are attainable in months',()=>{
 let b={...r.emptyBank(),enabled:true,balance:200,lifetimeEarned:200};
 assert.deepEqual(r.redeemPrize(b,'earrings','2026-10-25','x'),b);
 b=r.redeemPrize(b,'coffee','2026-10-25','c');assert.equal(b.balance,80);assert.equal(b.entries[0].points,-120);
 assert.equal(r.projectedWeeks(r.PRIZES.find(p=>p.id==='earrings').points),15);
 assert.equal(r.projectedWeeks(r.PRIZES.find(p=>p.id==='earrings').points,r.TYPICAL_WEEKLY_POINTS),26);
 assert.deepEqual(r.projectedTimeframe(5200),{fastWeeks:15,steadyWeeks:26});
});
test('peas visual counts track actual balance and never render hundreds of tokens',()=>{
 assert.deepEqual(r.peasVisible(0),{shown:0,banked:0,extra:0,towardNext:0});
 assert.deepEqual(r.peasVisible(24),{shown:1,banked:1,extra:0,towardNext:4});
 assert.deepEqual(r.peasVisible(5200),{shown:35,banked:260,extra:225,towardNext:0});
});
test('wisdom has real source links and rotates by date',()=>{
 assert.equal(w.WISDOM.length,5);
 for(const entry of w.WISDOM){assert.match(entry.url,/^https:\/\/heritage\.iitk\.ac\.in\/SBG\/\d+\.\d+$/);assert.match(entry.ref,/Bhagavad Gita/);}
 assert.notDeepEqual(w.dailyWisdom('2026-10-25'),w.dailyWisdom('2026-10-26'));
});

test('all rewards are achievable within the revised limits and activities are positive',()=>{
 assert.equal(r.WEEKLY_POINTS_CAP,360);
 assert.ok(r.ACTIVITIES.every(a=>a.points>0&&a.points<r.WEEKLY_POINTS_CAP));
 assert.ok(r.PRIZES.every(p=>p.points>0&&p.points<6000));
 assert.equal(r.PRIZES.find(p=>p.id==='coffee').points,120);
 assert.equal(r.PRIZES.find(p=>p.id==='book').points,250);
 assert.equal(r.PRIZES.find(p=>p.id==='earrings').points,5200);
});
