const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const ts=require('typescript');
const root=path.resolve(__dirname,'..');
function imported(file){let p=path.join(root,file);const js=ts.transpileModule(fs.readFileSync(p,'utf8'),{fileName:p,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const m=new Module(p,module);m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));m._compile(js,p);return m.exports;}
const r=imported('src/rewards.ts');
test('both users can record the actor for awarded activities',()=>{
 let bank={...r.emptyBank(),enabled:true};bank=r.claimActivity(bank,'dishes','2026-10-25','a','Chris');
 assert.equal(bank.balance,22);assert.equal(bank.entries[0].awardedBy,'Chris');
 bank=r.claimActivity(bank,'sweep','2026-10-25','b','Pankhuri');
 assert.equal(bank.balance,40);assert.equal(bank.entries[0].awardedBy,'Pankhuri');
});
test('a one-per-person bonus cannot be doubled and is capped per week',()=>{
 let b={...r.emptyBank(),enabled:true};b=r.giveBonus(b,60,'2026-10-25','a','Chris','Thank you for lunch');
 assert.equal(b.balance,60);assert.equal(b.entries[0].personalNote,'Thank you for lunch');
 assert.deepEqual(r.giveBonus(b,40,'2026-10-25','b','Chris','again'),b);
 b=r.giveBonus(b,20,'2026-10-25','c','Pankhuri');assert.equal(b.balance,80);
 assert.deepEqual(r.giveBonus(b,140,'2026-10-26','d','Chris'),b);
 let num=0;for(let day=26;day<=31;day++)for(let a of r.ACTIVITIES)b=r.claimActivity(b,a.id,`2026-10-${day}`,`x${num++}`,'Chris');
 assert.ok(r.pointsThisWeek(b,'2026-10-25')<=r.WEEKLY_POINTS_CAP);
});
test('new animation components parse, preserve reduced-motion support',()=>{
 for(const f of ['src/PeaJar.tsx','src/WelcomeSplash.tsx']){
  let code=fs.readFileSync(path.join(root,f),'utf8');const parsed=ts.createSourceFile(f,code,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
  assert.deepEqual(parsed.parseDiagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,' ')),[]);
  assert.match(code,/AccessibilityInfo\.isReduceMotionEnabled/);
 }
 const app=fs.readFileSync(path.join(root,'App.tsx'),'utf8');
 assert.match(app,/greetNow\(\)/);assert.match(app,/<PeaJar points=/);assert.match(app,/<WelcomeSplash\/>/);assert.doesNotMatch(app,/Good morning,\\nPankhuri/);
});
test('v1.6 keeps existing local data and only enables OTA after linking a real project',()=>{
 const app=fs.readFileSync(path.join(root,'App.tsx'),'utf8');assert.match(app,/const STORAGE_KEY='pea\.planner\.v1'/);
 const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
 const cfg=JSON.parse(fs.readFileSync(path.join(root,'app.json'),'utf8'));
 assert.equal(pkg.version,'1.6.0');assert.ok(pkg.dependencies['expo-updates']);assert.equal(cfg.expo.updates.enabled,false);assert.deepEqual(cfg.expo.runtimeVersion,{policy:'appVersion'});
 const cli=fs.readFileSync(path.join(root,'scripts/enable-ota.mjs'),'utf8');assert.match(cli,/u\.expo\.dev/);assert.match(cli,/uuid/);
});
