const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');

function loadTS(file) {
 const source = fs.readFileSync(file, 'utf8');
 const js = ts.transpileModule(source, {fileName:file, compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const mod = new Module(file, module);
 mod.filename = file;
 mod.paths = Module._nodeModulePaths(path.dirname(file));
 mod._compile(js,file);
 return mod.exports;
}
const data = loadTS(path.join(__dirname,'../src/data.ts'));

test('initial planner contains home responsibilities and no user-specific student record',()=>{
 const state=data.initialState();
 assert.ok(state.tasks.some(t=>t.title==='Pack school lunches'));
 assert.ok(state.tasks.some(t=>t.title==='Do the dishes'));
 assert.ok(state.tasks.every(t=>!('studentName' in t) && !('sevisId' in t)));
 assert.equal(state.reminder.enabled,false);
 assert.equal(state.reminder.revealOnToday,false);
 assert.equal(state.events.length,0);
});

test('meal IDs are unique and every meal has ingredients',()=>{
 assert.equal(new Set(data.meals.map(m=>m.id)).size,data.meals.length);
 for (const m of data.meals) {
   assert.ok(['lunch','dinner'].includes(m.kind));
   assert.ok(m.ingredients.length > 0);
   assert.ok(m.minutes > 0);
 }
});

test('date key retains local calendar day and rollover across months',()=>{
 assert.equal(data.dayKey(new Date(2026,0,31,12)),'2026-01-31');
 assert.equal(data.dayKey(data.addDays(new Date(2026,0,31,12),1)),'2026-02-01');
});

test('official resource urls use https',()=>{
 for (const r of data.officialResources) assert.equal(new URL(r.url).protocol,'https:');
});

test('Me Time starts empty and protects family data during migration',()=>{
 const state=data.initialState();
 assert.deepEqual(state.treats,[]);
 assert.equal(data.treatCategories.length,6);
 assert.equal(new Set(data.treatCategories.map(c=>c.id)).size,6);
});

test('Me Time statuses use natural labels for books movies beauty and TikTok',()=>{
 assert.equal(data.treatStatusLabel('thriller','saved'),'Want to read');
 assert.equal(data.treatStatusLabel('romance','started'),'Reading');
 assert.equal(data.treatStatusLabel('movie','done'),'Watched');
 assert.equal(data.treatStatusLabel('beauty','saved'),'Wishlist');
 assert.equal(data.treatStatusLabel('tiktok','done'),'Tried');
 assert.equal(data.nextTreatStatus('saved'),'started');
 assert.equal(data.nextTreatStatus('started'),'done');
 assert.equal(data.nextTreatStatus('done'),'saved');
});

test('Me Time validates saved external links, rejecting unsafe URLs',()=>{
 assert.equal(data.safePersonalLink(''),true);
 assert.equal(data.safePersonalLink('https://www.sephora.com/'),true);
 assert.equal(data.safePersonalLink(' https://www.tiktok.com/@creator/video/123 '),true);
 assert.equal(data.safePersonalLink('javascript:alert(1)'),false);
 assert.equal(data.safePersonalLink('http://example.com'),false);
 assert.equal(data.safePersonalLink('https://'),false);
});
