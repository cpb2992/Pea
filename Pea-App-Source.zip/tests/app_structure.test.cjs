const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const app=fs.readFileSync(path.join(__dirname,'../App.tsx'),'utf8');
test('entrypoint contains the real Pea app and rewards screen',()=>{
 assert.match(app,/export default Main/);
 assert.match(app,/function rewardsScreen\(/);
 assert.match(app,/glassJar/);
 assert.match(app,/function familyScreen\(/);
 assert.match(app,/function policyScreen\(/);
});
test('Pea app JSX has no syntax parse errors',()=>{
 const source=ts.createSourceFile('App.tsx',app,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 assert.equal(source.parseDiagnostics.length,0,source.parseDiagnostics.map(e=>ts.flattenDiagnosticMessageText(e.messageText,' ')).join(' | '));
});
