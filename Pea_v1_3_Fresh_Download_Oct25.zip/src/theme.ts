export const colors = {
  bg: '#FCF9F1',
  cream: '#FFFCF7',
  text: '#354930',
  muted: '#7B8375',
  green: '#849B75',
  greenSoft: '#F0F3EA',
  greenMid: '#DFE6D5',
  pink: '#E7A8A7',
  pinkSoft: '#FCEFED',
  pinkMid: '#F3D8D4',
  line: '#EAE8DF',
  white: '#FFFFFF',
  danger: '#B45465',
};
export const radii = { card: 23, pill: 99, small: 15 };
export const shadow = {
  shadowColor: '#65745F', shadowOffset: {width: 0, height: 5},
  shadowOpacity: 0.05, shadowRadius: 14, elevation: 1,
} as const;
